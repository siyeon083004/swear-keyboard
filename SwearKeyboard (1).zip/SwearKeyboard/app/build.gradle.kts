plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mine.swearkeyboard"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mine.swearkeyboard"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // 빌드할 때마다 같은 서명을 쓰게 (그래야 지우지 않고 업데이트 설치가 됨)
    signingConfigs {
        getByName("debug") {
            storeFile = file("swear.keystore")
            storePassword = "swearkey123"
            keyAlias = "swear"
            keyPassword = "swearkey123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
