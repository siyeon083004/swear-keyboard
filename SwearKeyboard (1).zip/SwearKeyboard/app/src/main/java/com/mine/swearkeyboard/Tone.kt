package com.mine.swearkeyboard

/** 말투 변환: 고운말 / 아이돌 팬싸 / 존댓말 ↔ 반말 */
object Tone {

    // ---------- 공통 ----------

    /** 문장 단위로 자르기 (구분 기호는 문장 끝에 붙어 있음) */
    private fun sentences(t: String): List<String> =
        t.split(Regex("""(?<=[.!?~\n])(?=[^.!?~\n])""")).filter { it.isNotEmpty() }

    private fun isJamo(c: Char) = c in 'ㄱ'..'ㆎ'

    /** "뭐해?? ㅋㅋ 😂" -> ("뭐해", "?? ㅋㅋ 😂") */
    private fun splitTail(s: String): Pair<String, String> {
        var i = s.length
        while (i > 0) {
            val c = s[i - 1]
            if (Hangul.isSyllable(c) || (c.isLetterOrDigit() && !isJamo(c))) break
            i--
        }
        return s.substring(0, i) to s.substring(i)
    }

    private fun mapSentences(t: String, f: (core: String, tail: String, index: Int) -> String): String =
        sentences(t).mapIndexed { i, s ->
            val (core, tail) = splitTail(s)
            if (core.isBlank()) s else f(core, tail, i)
        }.joinToString("")

    private fun lastWord(core: String): Pair<String, String> {
        val i = core.lastIndexOf(' ')
        return if (i < 0) "" to core else core.substring(0, i + 1) to core.substring(i + 1)
    }

    // 한 글자 분해·조립
    private fun parts(c: Char): IntArray? {
        if (!Hangul.isSyllable(c)) return null
        val code = c - '가'
        return intArrayOf(code / (21 * 28), (code % (21 * 28)) / 28, code % 28)
    }

    private fun build(ci: Int, ji: Int, ti: Int) = (0xAC00 + (ci * 21 + ji) * 28 + ti).toChar()

    private val V_A = Hangul.JUNG.indexOf('ㅏ')
    private val V_O = Hangul.JUNG.indexOf('ㅗ')

    /** 줄기 + 어/아: 먹→먹어, 앉→앉아, 가→가, 보→봐, 주→줘, 마시→마셔, 쓰→써, 하→해 */
    fun eoForm(stem: String): String {
        if (stem.isEmpty()) return stem
        val last = stem.last()
        val p = parts(last) ?: return stem + "어"
        val head = stem.dropLast(1)
        if (last == '하') return head + "해"
        if (p[2] != 0) return stem + (if (p[1] == V_A || p[1] == V_O) "아" else "어")
        val v = Hangul.JUNG[p[1]]
        val nv = when (v) {
            'ㅗ' -> 'ㅘ'; 'ㅜ' -> 'ㅝ'; 'ㅣ' -> 'ㅕ'; 'ㅡ' -> 'ㅓ'
            else -> return stem
        }
        return head + build(p[0], Hangul.JUNG.indexOf(nv), 0)
    }

    /** 배고파, 피곤해, 멀어처럼 '어/아'로 끝나는 반말인지 */
    private fun eoEnding(w: String): Boolean {
        if (w.isEmpty()) return false
        val c = w.last()
        if (c in "어아해워와봐줘돼네게래까데걸") return true
        if (c in "자다나가야") return false
        val p = parts(c) ?: return false
        return p[2] == 0 && Hangul.JUNG[p[1]] in "ㅏㅓㅐㅔㅕㅘㅝㅙㅞ"
    }

    // ---------- 😇 고운말 ----------

    val POLITE_MAP = listOf(
        "핵노잼" to "정말 재미없어", "개빡치" to "정말 화나", "개웃기" to "정말 웃기", "개웃겨" to "정말 웃겨",
        "개좋" to "정말 좋", "개쩔" to "정말 대단하", "개싫" to "정말 싫", "존나게" to "엄청", "존나" to "엄청",
        "졸라" to "엄청", "존내" to "엄청", "ㅈㄴ" to "엄청", "빡치" to "화나", "빡쳐" to "화나", "빡침" to "화남",
        "쩐다" to "대단하다", "쩔어" to "대단해", "쩔었" to "대단했", "극혐" to "정말 싫어", "노잼" to "재미없어",
        "꿀잼" to "정말 재밌어", "짜증나" to "속상해", "짜증" to "속상함", "개새끼" to "나쁜 사람", "새끼" to "녀석",
        "병신" to "바보", "닥쳐" to "조용히 해 줘", "꺼져" to "저리 가 줘", "지랄" to "난리", "미친놈" to "이상한 사람",
        "미친" to "정말", "좆같" to "정말 별로", "ㅅㅂ" to "아이고", "ㅆㅂ" to "아이고", "시발" to "아이고",
        "씨발" to "아이고", "ㅂㅅ" to "바보", "개같" to "별로", "엿먹어" to "너무해", "뒤질래" to "혼날래",
        "죽을래" to "혼날래", "개노답" to "정말 답이 없어", "킹받" to "약 오르"
    )

    fun polite(t: String, filter: SwearFilter? = null): String {
        var out = t
        for ((a, b) in POLITE_MAP.sortedByDescending { it.first.length }) out = out.replace(a, b)
        if (filter != null) out = filter.replaceAllWith(out, "아이고")
        return out
    }

    // ---------- 🎙 아이돌 팬싸 ----------

    private val DECO = listOf("💕", "🥺💗", "🍓✨", "💖", "🫶", "🎀💕", "🌸", "✨💞")
    private val CUTE_START = listOf("고마", "사랑", "좋아", "안녕", "보고싶", "보고 싶", "축하", "최고")

    fun idol(t: String): String = mapSentences(t) { core, tail, i ->
        val q = tail.contains('?')
        val bang = tail.contains('!')
        val rest = tail.replace(Regex("""[.!?~]"""), "").trim()
        val (head, w) = lastWord(core)
        val nw = when {
            w.endsWith("요") -> w + "오"
            w.endsWith("이야") -> w.dropLast(2) + "이에요오"
            w.endsWith("야") -> w.dropLast(1) + "예요오"
            w.endsWith("지") -> w.dropLast(1) + "죠오"
            w.endsWith("니") || w.endsWith("냐") -> w.dropLast(1) + "나요오"
            eoEnding(w) -> w + "요오"
            else -> "$w~"
        }
        val prefix = if (i == 0 && CUTE_START.any { core.contains(it) }) "꺄아 " else ""
        val deco = DECO[Math.abs(core.hashCode()) % DECO.size]
        val punct = when { q -> "??"; bang -> "!!"; else -> "" }
        prefix + head + nw + punct + " " + deco + (if (rest.isNotEmpty()) " $rest" else "") +
                (if (tail.endsWith("\n")) "\n" else if (tail.endsWith(" ")) " " else "")
    }

    // ---------- 🙇 존댓말 ↔ 반말 ----------

    fun isPolite(t: String): Boolean =
        sentences(t).any { s ->
            val core = splitTail(s).first.trim()
            core.endsWith("요") || core.endsWith("니다") || core.endsWith("니까") || core.endsWith("죠") ||
                    core == "네" || core == "넵" || core == "예"
        }

    private val TO_POLITE_WHOLE = mapOf(
        "ㅇㅋ" to "네", "ㅇㅇ" to "네", "응" to "네", "어" to "네", "웅" to "네", "ㅇ" to "네", "오키" to "네",
        "아니" to "아니요", "ㄴㄴ" to "아니요", "미안" to "죄송해요", "미안해" to "죄송해요", "고마워" to "감사해요",
        "ㄱㅅ" to "감사합니다", "ㄳ" to "감사합니다", "안녕" to "안녕하세요", "잘가" to "안녕히 가세요",
        "잘 가" to "안녕히 가세요", "잘자" to "안녕히 주무세요", "잘 자" to "안녕히 주무세요", "자" to "주무세요",
        "먹어" to "드세요", "밥 먹었어" to "식사하셨어요", "밥먹었어" to "식사하셨어요"
    )

    private val TO_BAN_WHOLE = mapOf(
        "네" to "응", "넵" to "응", "예" to "응", "아니요" to "아니", "아니에요" to "아니야",
        "감사합니다" to "고마워", "감사해요" to "고마워", "고마워요" to "고마워", "죄송합니다" to "미안해",
        "죄송해요" to "미안해", "안녕하세요" to "안녕", "안녕히 가세요" to "잘 가", "안녕히 주무세요" to "잘 자",
        "식사하셨어요" to "밥 먹었어", "주무세요" to "자"
    )

    private val PLAIN_JA = mapOf(
        "가자" to "가요", "하자" to "해요", "놀자" to "놀아요", "먹자" to "먹어요", "보자" to "봐요",
        "자자" to "자요", "오자" to "와요", "만나자" to "만나요", "하지마" to "하지 마세요"
    )

    private fun wordToPolite(w0: String): String {
        val w = w0.replace("먹었", "드셨")
        return when {
            PLAIN_JA.containsKey(w) -> PLAIN_JA.getValue(w)
            w.endsWith("이야") -> w.dropLast(2) + "이에요"
            w.endsWith("야") -> w.dropLast(1) + "예요"
            w.endsWith("었다") || w.endsWith("았다") || w.endsWith("였다") || w.endsWith("했다") || w.endsWith("겠다") ->
                w.dropLast(1) + "어요"
            w.endsWith("냐") || w.endsWith("니") -> w.dropLast(1) + "나요"
            w.endsWith("구나") -> w.dropLast(2) + "군요"
            w.endsWith("지") -> w.dropLast(1) + "죠"
            w.endsWith("거든") || w.endsWith("잖아") || w.endsWith("더라") -> w + "요"
            eoEnding(w) -> w + "요"
            else -> w
        }
    }

    private fun wordToBan(w0: String): String {
        val w = w0.replace("드셨", "먹었").replace("성함", "이름").replace("연세", "나이")
        when {
            w.endsWith("입니다") || w.endsWith("입니까") -> return w.dropLast(3) + "이야"
            w.endsWith("습니다") || w.endsWith("습니까") -> {
                val stem = w.dropLast(3)
                val p = stem.lastOrNull()?.let { parts(it) }
                val a = p != null && stem.last() !in "았었였겠" && (p[1] == V_A || p[1] == V_O)
                return stem + (if (a) "아" else "어")
            }
            w.endsWith("니다") || w.endsWith("니까") -> {
                // 갑니다 -> 가, 합니다 -> 해, 봅니다 -> 봐
                val body = w.dropLast(2)
                val c = body.lastOrNull() ?: return w
                val p = parts(c) ?: return w
                if (Hangul.JONG[p[2]] != 'ㅂ') return w
                return eoForm(body.dropLast(1) + build(p[0], p[1], 0))
            }
        }
        val special = mapOf(
            "하세요" to "해", "가세요" to "가", "오세요" to "와", "보세요" to "봐", "주세요" to "줘",
            "드세요" to "먹어", "어디세요" to "어디야", "누구세요" to "누구야", "뭐세요" to "뭐야",
            "계세요" to "있어", "주무세요" to "자", "하세요?" to "해?"
        )
        special[w]?.let { return it }
        for ((k, v) in special) if (w.endsWith(k)) return w.dropLast(k.length) + v
        return when {
            w.endsWith("이에요") -> w.dropLast(3) + "이야"
            w.endsWith("예요") || w.endsWith("에요") -> w.dropLast(2) + "야"
            w.endsWith("세요") -> eoForm(w.dropLast(2).removeSuffix("으"))
            w.endsWith("죠") -> w.dropLast(1) + "지"
            w.endsWith("나요") -> w.dropLast(2) + "냐"
            w.endsWith("군요") -> w.dropLast(2) + "구나"
            w.endsWith("요") -> w.dropLast(1)
            else -> w
        }
    }

    /** 존댓말이면 반말로, 반말이면 존댓말로 */
    fun honorific(t: String): String {
        val toBan = isPolite(t)
        return mapSentences(t) { core, tail, _ ->
            val lead = core.takeWhile { it == ' ' || it == '\n' }
            val c = core.trim()
            val whole = if (toBan) TO_BAN_WHOLE[c] else TO_POLITE_WHOLE[c]
            if (whole != null) return@mapSentences lead + whole + tail
            val (head, w) = lastWord(c)
            lead + head + (if (toBan) wordToBan(w) else wordToPolite(w)) + tail
        }
    }

    fun honorificLabel(t: String) = if (isPolite(t)) "🙇 반말로" else "🙇 존댓말로"
}
