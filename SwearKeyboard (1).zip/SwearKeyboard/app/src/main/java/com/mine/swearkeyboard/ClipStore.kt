package com.mine.swearkeyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 클립보드 저장소
 * - recent: 최근 복사한 글 (최대 MAX_RECENT개, 오래된 건 밀려남)
 * - cats: 내가 만든 분류(링크, 이름 ...) — 여기 넣은 건 영구 저장
 */
object ClipStore {
    private const val PREF = "clip_prefs"
    private const val KEY = "data"
    const val MAX_RECENT = 100

    class Cat(var name: String, val items: MutableList<String>)
    class Data(val recent: MutableList<String>, val cats: MutableList<Cat>)

    private fun defaultCats() = mutableListOf(
        Cat("링크", mutableListOf()),
        Cat("이름", mutableListOf()),
        Cat("주소", mutableListOf()),
        Cat("메모", mutableListOf())
    )

    private fun JSONArray?.toStrings(): MutableList<String> {
        val out = mutableListOf<String>()
        if (this == null) return out
        for (i in 0 until length()) out.add(optString(i))
        return out
    }

    fun load(ctx: Context): Data {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return Data(mutableListOf(), defaultCats())
        return try {
            val o = JSONObject(raw)
            val cats = mutableListOf<Cat>()
            val arr = o.optJSONArray("cats")
            if (arr != null) for (i in 0 until arr.length()) {
                val c = arr.getJSONObject(i)
                cats.add(Cat(c.optString("name"), c.optJSONArray("items").toStrings()))
            }
            Data(o.optJSONArray("recent").toStrings(), cats)
        } catch (e: Exception) {
            Data(mutableListOf(), defaultCats())
        }
    }

    fun save(ctx: Context, d: Data) {
        val o = JSONObject()
        o.put("recent", JSONArray(d.recent))
        val arr = JSONArray()
        for (c in d.cats) arr.put(JSONObject().put("name", c.name).put("items", JSONArray(c.items)))
        o.put("cats", arr)
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    fun addRecent(ctx: Context, t: String) {
        val d = load(ctx)
        if (d.recent.firstOrNull() == t) return
        d.recent.remove(t)
        d.recent.add(0, t)
        while (d.recent.size > MAX_RECENT) d.recent.removeAt(d.recent.size - 1)
        save(ctx, d)
    }
}
