package com.mine.swearkeyboard

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputContentInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class SwearKeyboardService : InputMethodService() {

    companion object {
        const val EMOJI = "😓"
        const val NO_FILTER = "com.mine.swearkeyboard.nofilter"

        const val KO1 = "ㅂㅈㄷㄱㅅㅛㅕㅑㅐㅔ"
        const val KO1_SHIFT = "ㅃㅉㄸㄲㅆㅛㅕㅑㅒㅖ"
        const val KO2 = "ㅁㄴㅇㄹㅎㅗㅓㅏㅣ"
        const val KO3 = "ㅋㅌㅊㅍㅠㅜㅡ"
        const val EN1 = "qwertyuiop"
        const val EN2 = "asdfghjkl"
        const val EN3 = "zxcvbnm"

        // 길게 누르면 나오는 것 (줄마다)
        const val LONG1 = "1234567890"
        const val LONG2 = "!@#₩%^&*("
        const val LONG3 = "-'\":;,?"

        // 삼성 키보드 기호 순서 (1/3, 2/3, 3/3)
        val SYM_PAGES = listOf(
            listOf("+×÷=/_<>[]", "!@#₩%^&*()", "-'\":;,?"),
            listOf("`~\\|{}€£¥$", "°•○●□■♤♡◇♧", "☆▪¤《》¡¿"),
            listOf("↑↓←→↔↕※♥♠♣", "◆★♪♬✓✕「」『』", "…·♀♂℃‰§")
        )

        // 삼성 키보드 크기에 맞춤
        const val ROW_H = 43      // 키 높이(dp)
        const val ROW_M = 5       // 키 위아래 여백(dp)
        const val KEY_GAP = 3     // 키 좌우 여백(dp)
        const val TOP_H = 44      // 도구줄/추천줄 높이(dp)

        val EMOJIS = ("😀 😂 🤣 😊 😍 🥰 😘 😎 🤔 😅 😭 😢 😡 🤬 😱 😴 🙄 😏 😬 🥺 😳 🤯 🤗 🤭 " +
                "😇 🥲 😤 😩 😓 😐 🫠 🤮 👍 👎 👏 🙏 💪 👌 ✌️ 🤞 👋 🫶 ❤️ 🧡 💛 💚 💙 💜 " +
                "🖤 💔 💯 🔥 ✨ 🎉 💀 👀 🤡 💩 ⭐ 🌙 ☀️ 🍀 🍕 🍔 🍗 🍜 🍰 ☕ 🎮 ⚽ 🎵 📱 💤 ❗ ❓ ✅ ❌")
            .split(" ")
    }

    enum class Mode { KO, EN, SYM }
    enum class Panel { KEYS, EMOJI, CLIP, TONE }

    private class Key(
        val label: String,
        val weight: Float = 1f,
        val special: Boolean = false,
        val spacer: Boolean = false,
        val repeat: Boolean = false,
        val highlight: Boolean = false,
        val space: Boolean = false,
        val longText: String? = null,
        val onLong: (() -> Unit)? = null,
        val action: () -> Unit = {}
    )

    private var mode = Mode.KO
    private var lastLang = Mode.KO
    private var shift = false
    private var syl = Syl()
    private var filter = SwearFilter.of(Words.DEFAULT)
    private var filterOn = true
    private var isPassword = false
    private var emojiLabel = EMOJI

    // 욕을 바꾼 직후, 이어서 치는 글자가 더 긴 욕이면(시바 -> 시발) 계속 삼키기
    private var repActive = false
    private var repJamo = ""
    private val repExtra = StringBuilder()

    private var panel = Panel.KEYS
    private var symPage = 0
    private var clipTab = -1                 // -1 = 최근, -2 = 사진, 0.. = 내 분류
    private var clipAction: String? = null   // 길게 누른 글
    private var clipListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    // 추천줄
    private var suggestions: List<Suggest.Sug> = emptyList()
    private var otpShown: String? = null
    private var suggestHidden = false
    private val sugRunnable = Runnable { refreshSuggest() }

    // 색 (폰이 다크모드면 어둡게, 아니면 삼성 키보드처럼 밝게)
    private var cBg = 0
    private var cKey = 0
    private var cSpecial = 0
    private var cText = 0
    private var cKeyDown = 0
    private var cSpecialDown = 0
    private var cBar = 0

    private var root: LinearLayout? = null
    private var topBar: LinearLayout? = null
    private var body: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())

    // ---------- 생명주기 ----------

    override fun onCreate() {
        super.onCreate()
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val l = ClipboardManager.OnPrimaryClipChangedListener { recordClip() }
        cm.addPrimaryClipChangedListener(l)
        clipListener = l
    }

    override fun onDestroy() {
        clipListener?.let { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).removePrimaryClipChangedListener(it) }
        super.onDestroy()
    }

    /** 복사한 글·사진을 클립보드 기록에 저장 */
    private fun recordClip() {
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            val item = clip.getItemAt(0)
            val uri = item.uri
            if (uri != null && clip.description.hasMimeType("image/*")) {
                if (uri.authority != ImageClips.AUTH) Thread { ImageClips.saveFromUri(this, uri) }.start()
                return
            }
            val t = item.coerceToText(this)?.toString()?.trim()
            if (!t.isNullOrEmpty()) ClipStore.addRecent(this, t)
        } catch (e: Exception) {
        }
    }

    override fun onCreateInputView(): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), 0, dp(5), dp(8))
        }
        val t = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val b = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(t, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(TOP_H)))
        r.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root = r
        topBar = t
        body = b
        build()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        filter = SwearFilter(Words.loadMap(this))
        emojiLabel = Words.defaultEmoji(this)
        isPassword = info?.let { passwordField(it) } ?: false
        val pkg = info?.packageName
        if (pkg != null && pkg != packageName) AppPrefs.addSeen(this, pkg)
        filterOn = info != null && !isPassword &&
                info.privateImeOptions?.contains(NO_FILTER) != true &&
                (pkg == null || !AppPrefs.isDisabled(this, pkg))
        syl = Syl()
        clearRep()
        shift = false
        panel = Panel.KEYS
        suggestHidden = false
        if (mode == Mode.SYM) mode = lastLang
        build()
        refreshSuggest()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        finishComposing()
        clearRep()
        super.onFinishInputView(finishingInput)
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // 사용자가 커서를 다른 곳으로 옮기면 조합 끝내기
        if (!syl.isEmpty && candidatesEnd != -1 &&
            (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)
        ) {
            currentInputConnection?.finishComposingText()
            syl = Syl()
            clearRep()
        }
        handler.removeCallbacks(sugRunnable)
        handler.postDelayed(sugRunnable, 40)
    }

    private fun passwordField(info: EditorInfo): Boolean {
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val v = info.inputType and InputType.TYPE_MASK_VARIATION
        return (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)) ||
                (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
    }

    // ---------- 입력 처리 ----------

    private fun onCharKey(s: String) {
        if (mode == Mode.KO && s.length == 1 && Hangul.isJamoKey(s[0])) onJamo(s[0]) else onText(s)
        if (shift) {
            shift = false
            build()
        }
    }

    private fun onJamo(k: Char) {
        val ic = currentInputConnection ?: return
        suggestHidden = false
        if (repActive) {
            val cand = repJamo + repExtra + k
            when (filter.continues(cand)) {
                2 -> { repJamo = cand; repExtra.clear(); return }
                1 -> { repExtra.append(k); return }
            }
            val pending = repExtra.toString()
            clearRep()
            for (p in pending) composeJamo(ic, p)
        }
        composeJamo(ic, k)
        checkSwear()
    }

    private fun composeJamo(ic: InputConnection, k: Char) {
        val (commit, next) = Composer.input(syl, k)
        if (commit.isNotEmpty()) ic.commitText(commit, 1)
        syl = next
        ic.setComposingText(syl.text(), 1)
    }

    private fun onText(s: String) {
        val ic = currentInputConnection ?: return
        suggestHidden = false
        flushRep(ic)
        finishComposing()
        ic.commitText(s, 1)
        checkSwear()
    }

    private fun textBefore(n: Int): String {
        val ic = currentInputConnection ?: return ""
        val comp = if (syl.isEmpty) "" else syl.text()
        var before = ic.getTextBeforeCursor(n, 0)?.toString() ?: ""
        if (comp.isNotEmpty() && !before.endsWith(comp)) before += comp
        return before
    }

    private fun checkSwear() {
        if (!filterOn) return
        val ic = currentInputConnection ?: return
        val before = textBefore(64)
        val m = filter.matchEnd(before) ?: return
        val matched = before.takeLast(m.len)

        ic.beginBatchEdit()
        ic.finishComposingText()
        ic.deleteSurroundingText(m.len, 0)
        ic.commitText(m.emoji, 1)
        ic.endBatchEdit()

        syl = Syl()
        repActive = mode == Mode.KO
        repJamo = Hangul.toJamo(matched.lowercase().filter { SwearFilter.SEP.indexOf(it) < 0 })
        repExtra.clear()
        Stats.record(this, m.word)
    }

    private fun clearRep() {
        repActive = false
        repJamo = ""
        repExtra.clear()
    }

    /** 삼켜두었던 글자가 욕이 아니었으면 다시 입력 */
    private fun flushRep(ic: InputConnection) {
        if (!repActive) return
        val pending = repExtra.toString()
        clearRep()
        for (p in pending) composeJamo(ic, p)
    }

    private fun finishComposing() {
        if (!syl.isEmpty) {
            currentInputConnection?.finishComposingText()
            syl = Syl()
        }
    }

    private fun endInputState() {
        currentInputConnection?.let { flushRep(it) }
        finishComposing()
        clearRep()
    }

    private fun onBackspace() {
        val ic = currentInputConnection ?: return
        if (repActive && repExtra.isNotEmpty()) {
            repExtra.deleteCharAt(repExtra.length - 1)
            return
        }
        clearRep()
        if (!syl.isEmpty) {
            syl = Composer.backspace(syl)
            if (syl.isEmpty) ic.commitText("", 1) else ic.setComposingText(syl.text(), 1)
            return
        }
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
            return
        }
        val b = ic.getTextBeforeCursor(2, 0)
        if (b.isNullOrEmpty()) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            return
        }
        val n = if (b.length == 2 && Character.isSurrogatePair(b[0], b[1])) 2 else 1
        ic.deleteSurroundingText(n, 0)
    }

    private fun onEnter() {
        val ic = currentInputConnection ?: return
        endInputState()
        val ei = currentInputEditorInfo
        val opts = ei?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnter = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnter && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun moveCursor(d: Int) {
        sendDownUpKeyEvents(if (d > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT)
    }

    /** 🔁 도배: 마지막 글자를 n번 더 */
    private fun spam(times: Int) {
        val ic = currentInputConnection ?: return
        endInputState()
        val b = ic.getTextBeforeCursor(4, 0)?.toString() ?: return
        if (b.isEmpty()) return
        var end = b.length
        if (b[end - 1] == '️' && end > 1) end--
        var start = end - 1
        if (start > 0 && Character.isSurrogatePair(b[start - 1], b[start])) start--
        val unit = b.substring(start, b.length)
        ic.commitText(unit.repeat(times), 1)
    }

    private fun toggleLang() {
        endInputState()
        mode = when (mode) {
            Mode.KO -> Mode.EN
            Mode.EN -> Mode.KO
            Mode.SYM -> if (lastLang == Mode.KO) Mode.EN else Mode.KO
        }
        lastLang = mode
        shift = false
        build()
    }

    private fun toggleSym() {
        endInputState()
        mode = if (mode == Mode.SYM) lastLang else Mode.SYM
        symPage = 0
        shift = false
        build()
    }

    private fun showPicker() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ---------- 추천줄 ----------

    private fun refreshSuggest() {
        val old = suggestions
        val list = ArrayList<Suggest.Sug>()
        if (!isPassword && panel == Panel.KEYS) {
            val otp = OtpStore.get(this)
            otpShown = otp
            if (otp != null) list.add(Suggest.Sug("🔢 $otp", 0, otp))
            val before = textBefore(64)
            if (before.isNotEmpty()) {
                for (s in Suggest.compute(before)) {
                    // 추천 결과에 욕이 섞이면 그것도 바꾸기 (tlqkf -> 시발 같은 경우)
                    list.add(if (filterOn) Suggest.Sug(filter.replaceAll(s.label), s.replaceLen, filter.replaceAll(s.insert)) else s)
                }
            }
        }
        suggestions = list
        if (old != list) updateTop()
    }

    private fun applySug(s: Suggest.Sug) {
        val ic = currentInputConnection ?: return
        endInputState()
        ic.beginBatchEdit()
        if (s.replaceLen > 0) ic.deleteSurroundingText(s.replaceLen, 0)
        ic.commitText(s.insert, 1)
        ic.endBatchEdit()
        if (otpShown != null && s.insert == otpShown) OtpStore.clear(this)
        refreshSuggest()
    }

    // ---------- 화면 ----------

    private fun applyTheme() {
        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        if (dark) {
            cBg = 0xFF1E1F24.toInt(); cKey = 0xFF5B5E69.toInt(); cSpecial = 0xFF3A3C44.toInt(); cText = Color.WHITE
            cKeyDown = 0xFF7A7E8A.toInt(); cSpecialDown = 0xFF555863.toInt(); cBar = 0xFF26272D.toInt()
        } else {
            cBg = 0xFFECEEF1.toInt(); cKey = Color.WHITE; cSpecial = 0xFFD5D8DE.toInt(); cText = 0xFF1B1B1F.toInt()
            cKeyDown = 0xFFD2D5DB.toInt(); cSpecialDown = 0xFFBFC3CB.toInt(); cBar = 0xFFF5F6F8.toInt()
        }
    }

    private fun build() {
        val r = root ?: return
        val b = body ?: return
        applyTheme()
        r.setBackgroundColor(cBg)
        topBar?.setBackgroundColor(cBar)
        updateTop()
        b.removeAllViews()
        when (panel) {
            Panel.KEYS -> buildKeys()
            Panel.EMOJI -> emojiPanel()
            Panel.CLIP -> clipPanel()
            Panel.TONE -> tonePanel()
        }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat()
        setColor(color)
    }

    private fun haptic(v: View) = v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)

    /** 맨 위 줄: 추천이 있으면 추천줄, 없으면 도구줄 */
    private fun updateTop() {
        val bar = topBar ?: return
        bar.removeAllViews()
        if (panel == Panel.KEYS && suggestions.isNotEmpty() && !suggestHidden) {
            val chips = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            for (s in suggestions) {
                chips.addView(TextView(this).apply {
                    text = s.label
                    textSize = 16f
                    maxLines = 1
                    gravity = Gravity.CENTER
                    setTextColor(cText)
                    background = rounded(cKey, 18)
                    setPadding(dp(14), 0, dp(14), 0)
                    setOnClickListener { haptic(it); applySug(s) }
                }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(36)).apply { setMargins(dp(4), 0, dp(4), 0) })
            }
            bar.addView(HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(chips)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
            bar.addView(TextView(this).apply {
                text = "✕"
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(cText)
                setOnClickListener { suggestHidden = true; updateTop() }
            }, LinearLayout.LayoutParams(dp(40), LinearLayout.LayoutParams.MATCH_PARENT))
            return
        }
        fun tool(label: String, active: Boolean, onLong: (() -> Unit)? = null, onClick: () -> Unit) {
            val tv = TextView(this).apply {
                text = label
                textSize = 20f
                gravity = Gravity.CENTER
                setTextColor(cText)
                if (active) background = rounded(cSpecial, 20)
                setOnClickListener { haptic(it); onClick() }
                if (onLong != null) setOnLongClickListener { haptic(it); onLong(); true }
            }
            bar.addView(tv, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(4), dp(2), dp(4), dp(2)) })
        }
        tool("😊", panel == Panel.EMOJI) { switchPanel(Panel.EMOJI) }
        tool("📋", panel == Panel.CLIP) { switchPanel(Panel.CLIP) }
        tool("🗣", panel == Panel.TONE) { switchPanel(Panel.TONE) }
        tool("🔁", false, onLong = { spam(20) }) { spam(5) }
        tool("⚙️", false) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        tool("⌨️", false) { showPicker() }
    }

    private fun switchPanel(p: Panel) {
        endInputState()
        panel = if (panel == p) Panel.KEYS else p
        clipAction = null
        if (panel == Panel.CLIP) recordClip()
        build()
        if (panel == Panel.KEYS) refreshSuggest()
    }

    /** 이모티콘·클립보드·말투 화면 높이 = 자판 4줄 */
    private fun panelHeight() = dp((ROW_H + ROW_M * 2) * 4)

    private fun addToBody(v: View, height: Int) {
        body?.addView(v, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height))
    }

    private fun panelBottomRow() {
        val back = if (lastLang == Mode.KO) "가" else "ABC"
        row(
            listOf(
                Key(back, 1.6f, special = true) { panel = Panel.KEYS; build(); refreshSuggest() },
                Key("$emojiLabel 키보드", 4f, space = true),
                backKey()
            )
        )
    }

    // ---------- 😊 이모티콘 ----------

    private fun emojiPanel() {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (chunk in EMOJIS.chunked(8)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (e in chunk) {
                r.addView(TextView(this).apply {
                    text = e
                    textSize = 26f
                    gravity = Gravity.CENTER
                    setOnClickListener { haptic(it); onText(e) }
                }, LinearLayout.LayoutParams(0, dp(50), 1f))
            }
            repeat(8 - chunk.size) { r.addView(View(this), LinearLayout.LayoutParams(0, dp(50), 1f)) }
            grid.addView(r)
        }
        addToBody(ScrollView(this).apply { addView(grid) }, panelHeight())
        panelBottomRow()
    }

    // ---------- 🗣 말투 ----------

    private fun tonePanel() {
        val ic = currentInputConnection
        val before = ic?.getTextBeforeCursor(5000, 0)?.toString() ?: ""
        val after = ic?.getTextAfterCursor(5000, 0)?.toString() ?: ""
        val full = before + after
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun info(t: String) = list.addView(TextView(this).apply {
            text = t
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(cText)
            setPadding(dp(8), dp(14), dp(8), dp(6))
        })
        if (full.isBlank()) {
            info("먼저 글을 쓰고 🗣를 누르면\n쓴 글 전체를 바꿔줘요.")
        } else {
            info("누르면 쓴 글 전체가 이렇게 바뀌어요")
            val options = listOf(
                "😇 고운말" to Tone.polite(full, filter),
                "🎙 아이돌 팬싸" to Tone.idol(full),
                Tone.honorificLabel(full) to Tone.honorific(full)
            )
            for ((title, result) in options) {
                list.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(cKey, 10)
                    setPadding(dp(14), dp(10), dp(14), dp(10))
                    addView(TextView(this@SwearKeyboardService).apply {
                        text = title
                        textSize = 13f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(cText)
                    })
                    addView(TextView(this@SwearKeyboardService).apply {
                        text = result
                        textSize = 15f
                        maxLines = 3
                        ellipsize = TextUtils.TruncateAt.END
                        setTextColor(cText)
                    })
                    setOnClickListener {
                        haptic(it)
                        val c = currentInputConnection ?: return@setOnClickListener
                        c.beginBatchEdit()
                        c.finishComposingText()
                        c.deleteSurroundingText(before.length, after.length)
                        c.commitText(result, 1)
                        c.endBatchEdit()
                        syl = Syl()
                        panel = Panel.KEYS
                        build()
                    }
                }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
        }
        addToBody(ScrollView(this).apply { addView(list) }, panelHeight())
        panelBottomRow()
    }

    // ---------- 📋 클립보드 ----------

    private fun clipPanel() {
        val data = ClipStore.load(this)
        if (clipTab >= data.cats.size) clipTab = -1

        // 위쪽 탭: 최근 | 사진 | 링크 | 이름 ...
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun tab(label: String, idx: Int) {
            tabs.addView(TextView(this).apply {
                text = label
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(if (clipTab == idx) Color.WHITE else cText)
                background = rounded(if (clipTab == idx) 0xFF4C8DF6.toInt() else cSpecial, 16)
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { clipTab = idx; clipAction = null; build() }
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(32)).apply { setMargins(dp(3), dp(4), dp(3), dp(4)) })
        }
        tab("🕘 최근 ${data.recent.size}", -1)
        tab("🖼 사진", -2)
        data.cats.forEachIndexed { i, c -> tab("📌 ${c.name} ${c.items.size}", i) }
        addToBody(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tabs)
        }, dp(40))

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val lp = {
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        }
        fun info(t: String) = list.addView(TextView(this).apply {
            text = t
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(cText)
            setPadding(dp(8), dp(20), dp(8), dp(8))
        })
        fun actionBtn(t: String, color: Int, onClick: () -> Unit) = list.addView(TextView(this).apply {
            text = t
            textSize = 15f
            setTextColor(if (color == cKey || color == cSpecial) cText else Color.WHITE)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(color, 8)
            setOnClickListener { haptic(it); onClick() }
        }, lp())

        val action = clipAction
        when {
            clipTab == -2 -> photoGrid(list)
            action != null -> {
                // 길게 누른 글: 분류에 고정 저장 / 삭제
                list.addView(TextView(this).apply {
                    text = action
                    textSize = 14f
                    maxLines = 3
                    ellipsize = TextUtils.TruncateAt.END
                    setTextColor(cText)
                    setPadding(dp(14), dp(10), dp(14), dp(10))
                })
                for ((i, c) in data.cats.withIndex()) {
                    if (i == clipTab) continue
                    actionBtn("📌 '${c.name}'에 고정 저장", cKey) {
                        if (action !in c.items) c.items.add(0, action)
                        ClipStore.save(this, data)
                        clipAction = null
                        clipTab = i
                        build()
                    }
                }
                actionBtn("🗑 삭제", 0xFFD9534F.toInt()) {
                    if (clipTab == -1) data.recent.remove(action) else data.cats[clipTab].items.remove(action)
                    ClipStore.save(this, data)
                    clipAction = null
                    build()
                }
                actionBtn("취소", cSpecial) { clipAction = null; build() }
            }
            else -> {
                val items = if (clipTab == -1) data.recent else data.cats[clipTab].items
                if (items.isEmpty()) {
                    info(
                        if (clipTab == -1) "복사한 글이 없어요.\n글을 복사하면 여기에 쌓여요. (최대 ${ClipStore.MAX_RECENT}개)"
                        else "아직 비어 있어요.\n'최근'에서 글을 길게 누르면 여기에 고정 저장할 수 있어요."
                    )
                } else {
                    info("누르면 붙여넣기 · 길게 누르면 고정 저장/삭제")
                }
                for (c in items) {
                    list.addView(TextView(this).apply {
                        text = c
                        textSize = 15f
                        maxLines = 2
                        ellipsize = TextUtils.TruncateAt.END
                        setTextColor(cText)
                        setPadding(dp(14), dp(12), dp(14), dp(12))
                        background = rounded(cKey, 8)
                        setOnClickListener { haptic(it); pasteText(c) }
                        setOnLongClickListener {
                            clipAction = c
                            build()
                            true
                        }
                    }, lp())
                }
            }
        }
        addToBody(ScrollView(this).apply { addView(list) }, panelHeight() - dp(40))
        panelBottomRow()
    }

    /** 🖼 복사한 사진 + 최근 스크린샷 */
    private fun photoGrid(list: LinearLayout) {
        val files = ImageClips.list(this)
        val shots = ImageClips.recentScreenshots(this, 16)
        val info = TextView(this).apply {
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(cText)
            setPadding(dp(8), dp(8), dp(8), dp(4))
            text = when {
                files.isEmpty() && shots.isEmpty() && !ImageClips.hasPhotoPermission(this@SwearKeyboardService) ->
                    "복사한 사진이 없어요.\n앱의 '설정' 탭에서 사진 접근을 허용하면 최근 스크린샷도 나와요."
                files.isEmpty() && shots.isEmpty() -> "복사한 사진이나 스크린샷이 없어요."
                else -> "누르면 붙여넣기 · 복사한 사진은 길게 누르면 삭제"
            }
        }
        list.addView(info)

        class Cell(val file: File?, val uri: Uri?)
        val cells = files.map { Cell(it, null) } + shots.map { Cell(null, it) }
        val size = dp(80)
        for (chunk in cells.chunked(4)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (cell in chunk) {
                val iv = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = rounded(cSpecial, 6)
                    clipToOutline = true
                    setOnClickListener {
                        haptic(it)
                        val f = cell.file ?: cell.uri?.let { u -> ImageClips.saveFromUri(this@SwearKeyboardService, u) }
                        if (f == null) toast("사진을 불러오지 못했어요") else commitImage(f)
                    }
                    if (cell.file != null) setOnLongClickListener {
                        ImageClips.delete(cell.file)
                        build()
                        true
                    }
                }
                r.addView(iv, LinearLayout.LayoutParams(0, size, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
                // 미리보기는 뒤에서 불러오기
                Thread {
                    val bmp: Bitmap? = if (cell.file != null) ImageClips.thumb(this, cell.file, size)
                    else cell.uri?.let { ImageClips.thumb(this, it, size) }
                    if (bmp != null) handler.post { iv.setImageBitmap(bmp) }
                }.start()
            }
            repeat(4 - chunk.size) { r.addView(View(this), LinearLayout.LayoutParams(0, size, 1f)) }
            list.addView(r)
        }
    }

    /** 사진 넣기: 받는 앱이면 바로, 아니면 클립보드에 복사 */
    private fun commitImage(f: File) {
        val ic = currentInputConnection ?: return
        val mime = ImageClips.mimeOf(f)
        val uri = ImageClips.uriFor(f)
        val types = currentInputEditorInfo?.contentMimeTypes
        val ok = types?.any { ClipDescription.compareMimeTypes(mime, it) } == true
        if (ok) {
            endInputState()
            val info = InputContentInfo(uri, ClipDescription("image", arrayOf(mime)), null)
            if (ic.commitContent(info, InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)) return
        }
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newUri(contentResolver, "image", uri))
            toast("이 앱은 키보드로 사진을 못 받아요.\n복사해 뒀으니 입력칸을 길게 눌러 붙여넣기 하세요")
        } catch (e: Exception) {
            toast("이 앱에는 사진을 넣을 수 없어요")
        }
    }

    /** 붙여넣는 글 안에 있는 욕도 전부 바꾸기 */
    private fun pasteText(t: String) {
        val ic = currentInputConnection ?: return
        endInputState()
        ic.commitText(if (filterOn) filter.replaceAll(t) else t, 1)
    }

    // ---------- 자판 ----------

    private fun letters(s: String, long: String? = null): List<Key> =
        s.mapIndexed { i, c ->
            val lt = long?.getOrNull(i)?.toString()
            Key(c.toString(), longText = lt) { onCharKey(c.toString()) }
        }

    private fun spacer(w: Float) = Key("", w, spacer = true)
    private fun shiftKey() = Key("⇧", 1.5f, special = true, highlight = shift) { shift = !shift; build() }
    private fun backKey() = Key("⌫", 1.5f, special = true, repeat = true) { onBackspace() }

    private fun buildKeys() {
        row(letters("1234567890"))
        when (mode) {
            Mode.KO -> {
                row(letters(if (shift) KO1_SHIFT else KO1, LONG1))
                row(listOf(spacer(0.5f)) + letters(KO2, LONG2) + spacer(0.5f))
                row(listOf(shiftKey()) + letters(KO3, LONG3) + backKey())
            }
            Mode.EN -> {
                fun f(s: String) = if (shift) s.uppercase() else s
                row(letters(f(EN1), LONG1))
                row(listOf(spacer(0.5f)) + letters(f(EN2), LONG2) + spacer(0.5f))
                row(listOf(shiftKey()) + letters(f(EN3), LONG3) + backKey())
            }
            Mode.SYM -> {
                val pg = SYM_PAGES[symPage]
                row(letters(pg[0]))
                row(letters(pg[1]))
                row(listOf(Key("${symPage + 1}/${SYM_PAGES.size}", 1.5f, special = true) {
                    symPage = (symPage + 1) % SYM_PAGES.size
                    build()
                }) + letters(pg[2]) + backKey())
            }
        }
        val symLabel = if (mode == Mode.SYM) (if (lastLang == Mode.KO) "가" else "ABC") else "!#1"
        val langLabel = if (mode == Mode.EN || (mode == Mode.SYM && lastLang == Mode.EN)) "영/한" else "한/영"
        row(
            listOf(
                Key(symLabel, 1.4f, special = true) { toggleSym() },
                Key(langLabel, 1f, special = true, onLong = { showPicker() }) { toggleLang() },
                Key(",", longText = "!") { onText(",") },
                Key("$emojiLabel 키보드", 4.2f, space = true),
                Key(".", longText = "?") { onText(".") },
                Key("⏎", 1.4f, special = true) { onEnter() }
            )
        )
    }

    private fun row(keys: List<Key>) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (k in keys) {
            val lp = LinearLayout.LayoutParams(0, dp(ROW_H), k.weight)
            lp.setMargins(dp(KEY_GAP), dp(ROW_M), dp(KEY_GAP), dp(ROW_M))
            r.addView(makeKey(k), lp)
        }
        body?.addView(r, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun makeKey(k: Key): View {
        if (k.spacer) return View(this)
        val color = when {
            k.highlight -> 0xFF4C8DF6.toInt()
            k.special -> cSpecial
            else -> cKey
        }
        val down = when {
            k.highlight -> 0xFF3A74D8.toInt()
            k.special -> cSpecialDown
            else -> cKeyDown
        }
        val frame = FrameLayout(this).apply {
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_pressed), rounded(down, 8))
                addState(intArrayOf(), rounded(color, 8))
            }
            elevation = if (k.special || k.highlight) 0f else dp(1).toFloat() / 2
            isClickable = true
            isSoundEffectsEnabled = false
        }
        frame.addView(TextView(this).apply {
            text = k.label
            gravity = Gravity.CENTER
            setTextColor(if (k.highlight) Color.WHITE else cText)
            textSize = if (k.label.length > 2) 15f else 20f
            if (k.special) typeface = Typeface.DEFAULT_BOLD
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        if (k.longText != null) {
            frame.addView(TextView(this).apply {
                text = k.longText
                textSize = 9f
                setTextColor(cText)
                alpha = 0.55f
                setPadding(0, dp(2), dp(4), 0)
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END))
        }

        when {
            k.repeat -> {
                val rep = object : Runnable {
                    override fun run() {
                        k.action()
                        handler.postDelayed(this, 50)
                    }
                }
                frame.setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            v.isPressed = true
                            haptic(v)
                            k.action()
                            handler.postDelayed(rep, 400)
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            v.isPressed = false
                            handler.removeCallbacks(rep)
                        }
                    }
                    true
                }
            }
            k.space -> spaceTouch(frame)
            else -> {
                frame.setOnClickListener { haptic(it); k.action() }
                val lt = k.longText
                when {
                    lt != null -> frame.setOnLongClickListener { haptic(it); onText(lt); true }
                    k.onLong != null -> frame.setOnLongClickListener { k.onLong.invoke(); true }
                }
            }
        }
        return frame
    }

    /** 스페이스바: 누르면 띄어쓰기, 좌우로 밀면 커서 이동 */
    private fun spaceTouch(v: View) {
        var startX = 0f
        var stepX = 0f
        var sliding = false
        val step = dp(12).toFloat()
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX
                    stepX = e.rawX
                    sliding = false
                    view.isPressed = true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!sliding && Math.abs(e.rawX - startX) > dp(16)) {
                        sliding = true
                        endInputState()
                        stepX = e.rawX
                    }
                    if (sliding) {
                        while (e.rawX - stepX >= step) { moveCursor(1); stepX += step; view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
                        while (stepX - e.rawX >= step) { moveCursor(-1); stepX -= step; view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    view.isPressed = false
                    if (!sliding) {
                        haptic(view)
                        onText(" ")
                    }
                }
                MotionEvent.ACTION_CANCEL -> { view.isPressed = false }
            }
            true
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
