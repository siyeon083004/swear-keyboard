package com.mine.swearkeyboard

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** 문자 알림에서 인증번호만 뽑아 3분 동안 키보드에 보여준다. (인터넷 권한 없음: 밖으로 안 나감) */
class OtpListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn?.notification ?: return
        if (sbn.packageName == packageName) return
        val ex = n.extras ?: return
        val text = listOfNotNull(
            ex.getCharSequence(Notification.EXTRA_TITLE),
            ex.getCharSequence(Notification.EXTRA_TEXT),
            ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
        ).joinToString(" ")
        if (text.isBlank()) return
        val code = OtpStore.extract(text) ?: return
        OtpStore.put(this, code)
    }
}
