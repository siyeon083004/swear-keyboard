package com.mine.swearkeyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var groups: Groups
    private val expanded = HashSet<String>()
    private lateinit var listBox: LinearLayout
    private lateinit var search: EditText
    private var tab = 0  // 0 = 욕 단어, 1 = 클립보드, 2 = 통계, 3 = 설정
    private val clipExpanded = HashSet<Int>()
    private val tabButtons = ArrayList<Button>()
    private lateinit var wordsTools: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        groups = Words.loadGroups(this)

        val pad = dp(18)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        col.addView(text("😓 키보드", 28f, true))
        col.addView(text("욕을 치는 순간 바로 이모지로 바뀌는 나만의 키보드예요. 전송을 아무리 빨리 눌러도 이미 바뀐 상태로 나가요."))

        col.addView(text("처음 한 번만 하면 돼요", 18f, true))
        col.addView(button("1단계: 설정에서 '😓 키보드' 켜기") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(button("2단계: 이 키보드로 바꾸기") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        // 탭: 욕 단어 | 클립보드 / 통계 | 설정
        val names = listOf("🚫 욕 단어", "📋 클립보드", "📊 욕 카운터", "🔧 설정")
        for (r in 0 until 2) {
            val tabs = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                if (r == 0) setPadding(0, dp(14), 0, 0)
            }
            for (c in 0 until 2) {
                val idx = r * 2 + c
                val b = Button(this).apply { text = names[idx]; setOnClickListener { tab = idx; render() } }
                tabButtons.add(b)
                tabs.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            col.addView(tabs)
        }

        wordsTools = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(wordsTools)
        wordsTools.addView(text("그룹을 누르면 그 안의 변형들이 펼쳐져요. ✕를 누르면 그 단어는 안 바뀌어요.", 13f))

        search = noFilterEdit("🔍 검색 (예: 씨발, 새끼, ㅅㅂ)").apply {
            isSingleLine = true
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = render()
            })
        }
        wordsTools.addView(search)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)

        val wordsBottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wordsBottomBox = wordsBottom
        col.addView(wordsBottom)
        wordsBottom.addView(button("+ 새 그룹 만들기") { newGroupDialog() })
        wordsBottom.addView(button("기본 목록으로 되돌리기") {
            AlertDialog.Builder(this)
                .setMessage("내가 추가하거나 지운 단어가 다 처음 상태로 돌아가요. 되돌릴까요?")
                .setPositiveButton("되돌리기") { _, _ ->
                    groups = Words.defaultGroups()
                    save()
                    render()
                }
                .setNegativeButton("취소", null)
                .show()
        })

        col.addView(text("여기서 테스트해 보세요", 18f, true))
        col.addView(EditText(this).apply { hint = "욕을 쳐보세요" })

        val scroll = ScrollView(this).apply { addView(col) }
        // 최신 안드로이드에서 위(상태바)·아래(내비게이션 바)에 가려지지 않게
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val b = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            }
            insets
        }
        setContentView(scroll)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::listBox.isInitialized) render()
    }

    private var wordsBottomBox: LinearLayout? = null

    // ---------- 목록 그리기 ----------

    private fun render() {
        tabButtons.forEachIndexed { i, b -> b.alpha = if (i == tab) 1f else 0.45f }
        wordsTools.visibility = if (tab == 0) View.VISIBLE else View.GONE
        wordsBottomBox?.visibility = if (tab == 0) View.VISIBLE else View.GONE
        when (tab) {
            1 -> { renderClip(); return }
            2 -> { renderStats(); return }
            3 -> { renderSettings(); return }
        }
        listBox.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        var shownAny = false

        for ((name, list) in groups) {
            val nameHit = q.isNotEmpty() && name.lowercase().contains(q)
            val matches = if (q.isEmpty() || nameHit) list else list.filter { it.lowercase().contains(q) }
            if (q.isNotEmpty() && matches.isEmpty() && !nameHit) continue
            shownAny = true

            val open = q.isNotEmpty() || name in expanded
            val title = buildString {
                append(if (open) "▼  " else "▶  ")
                append(name)
                append("   ${list.size}개")
                if (q.isNotEmpty() && !nameHit) append("  ·  ${matches.size}개 찾음")
            }
            listBox.addView(header(title) {
                if (q.isEmpty()) {
                    if (!expanded.remove(name)) expanded.add(name)
                    render()
                }
            })

            if (open) {
                for (w in matches) listBox.addView(wordRow(w) {
                    list.remove(w)
                    save()
                    render()
                })
                listBox.addView(addRow(name))
                val ge = Words.groupEmojis(this)[name]
                listBox.addView(Button(this).apply {
                    text = "바꿀 이모지: ${ge ?: Words.defaultEmoji(this@MainActivity) + " (기본)"}  ✏️"
                    textSize = 12f
                    setOnClickListener {
                        nameDialog("'$name'을(를) 무엇으로 바꿀까요? (비우면 기본 이모지)", ge ?: "", allowEmpty = true) { e ->
                            Words.setGroupEmoji(this@MainActivity, name, e)
                            render()
                        }
                    }
                })
                listBox.addView(smallButton("이 그룹 삭제") {
                    AlertDialog.Builder(this)
                        .setMessage("'$name' 그룹을 통째로 지울까요? (${list.size}개)")
                        .setPositiveButton("삭제") { _, _ ->
                            groups.remove(name)
                            expanded.remove(name)
                            save()
                            render()
                        }
                        .setNegativeButton("취소", null)
                        .show()
                })
            }
        }

        if (!shownAny && q.isNotEmpty()) {
            listBox.addView(text("'$q'은(는) 목록에 없어요.", 15f))
            listBox.addView(button("'$q' 추가하기") {
                addWord(Words.MY_GROUP, q)
                search.setText("")
            })
        }
    }

    // ---------- 클립보드 관리 ----------

    private fun renderClip() {
        listBox.removeAllViews()
        val data = ClipStore.load(this)
        listBox.addView(text("📌 분류에 넣은 글은 시간이 지나도 안 지워져요. 키보드의 📋에서 최근 글을 길게 눌러도 분류에 넣을 수 있어요.", 13f))

        data.cats.forEachIndexed { i, cat ->
            val open = i in clipExpanded
            listBox.addView(header("${if (open) "▼" else "▶"}  📌 ${cat.name}   ${cat.items.size}개") {
                if (!clipExpanded.remove(i)) clipExpanded.add(i)
                render()
            })
            if (!open) return@forEachIndexed
            for (item in cat.items.toList()) listBox.addView(wordRow(item) {
                val d = ClipStore.load(this)
                d.cats.getOrNull(i)?.items?.remove(item)
                ClipStore.save(this, d)
                render()
            })
            // 직접 추가
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), 0, 0, dp(4))
            }
            val input = noFilterEdit("여기에 저장할 글 쓰기").apply {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                        InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            }
            row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "저장"
                setOnClickListener {
                    val t = input.text.toString().trim()
                    if (t.isNotEmpty()) {
                        val d = ClipStore.load(this@MainActivity)
                        d.cats.getOrNull(i)?.let { if (t !in it.items) it.items.add(0, t) }
                        ClipStore.save(this@MainActivity, d)
                        render()
                    }
                }
            })
            listBox.addView(row)
            val btns = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
            }
            btns.addView(Button(this).apply {
                text = "이름 바꾸기"
                textSize = 12f
                setOnClickListener { nameDialog("분류 이름 바꾸기", cat.name) { n ->
                    val d = ClipStore.load(this@MainActivity)
                    d.cats.getOrNull(i)?.name = n
                    ClipStore.save(this@MainActivity, d)
                    render()
                } }
            })
            btns.addView(Button(this).apply {
                text = "분류 삭제"
                textSize = 12f
                setTextColor(0xFFD9534F.toInt())
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage("'${cat.name}' 분류와 안에 저장된 글 ${cat.items.size}개를 지울까요?")
                        .setPositiveButton("삭제") { _, _ ->
                            val d = ClipStore.load(this@MainActivity)
                            if (i < d.cats.size) d.cats.removeAt(i)
                            ClipStore.save(this@MainActivity, d)
                            clipExpanded.clear()
                            render()
                        }
                        .setNegativeButton("취소", null)
                        .show()
                }
            })
            listBox.addView(btns)
        }

        listBox.addView(button("+ 새 분류 만들기") {
            nameDialog("새 분류 (예: 링크, 이름, 계좌)", "") { n ->
                val d = ClipStore.load(this)
                d.cats.add(ClipStore.Cat(n, mutableListOf()))
                ClipStore.save(this, d)
                clipExpanded.add(d.cats.size - 1)
                render()
            }
        })

        listBox.addView(text("🕘 최근 복사한 글 ${data.recent.size}개 (최대 ${ClipStore.MAX_RECENT}개, 오래된 건 밀려나요)", 15f, true))
        listBox.addView(button("최근 목록 비우기") {
            AlertDialog.Builder(this)
                .setMessage("최근 복사한 글을 다 지울까요? (📌 분류에 넣은 건 그대로예요)")
                .setPositiveButton("비우기") { _, _ ->
                    val d = ClipStore.load(this)
                    d.recent.clear()
                    ClipStore.save(this, d)
                    render()
                }
                .setNegativeButton("취소", null)
                .show()
        })
    }

    // ---------- 📊 욕 카운터 ----------

    private fun renderStats() {
        listBox.removeAllViews()
        val st = Stats.snapshot(this)
        listBox.addView(text("오늘 막은 욕", 15f, true))
        listBox.addView(text("${st.today}번", 34f, true))
        listBox.addView(text("최근 7일 ${st.week}번 · 지금까지 ${st.total}번", 15f))

        listBox.addView(text("최근 7일", 15f, true))
        val max = (st.last7.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
        for ((d, n) in st.last7) {
            val bar = "▇".repeat(if (n == 0) 0 else (n * 12 / max).coerceAtLeast(1))
            listBox.addView(text("${d.substring(5)}  $bar $n", 14f).apply { setPadding(0, dp(2), 0, dp(2)) })
        }

        listBox.addView(text("🏆 많이 친 욕 TOP ${st.top.size}", 15f, true))
        if (st.top.isEmpty()) listBox.addView(text("아직 기록이 없어요. 욕을 참고 있군요 😇", 14f))
        st.top.forEachIndexed { i, (w, n) ->
            listBox.addView(text("${i + 1}.  $w  —  ${n}번", 15f).apply { setPadding(0, dp(3), 0, dp(3)) })
        }

        listBox.addView(smallButton("기록 초기화") {
            AlertDialog.Builder(this)
                .setMessage("욕 카운터 기록을 전부 지울까요?")
                .setPositiveButton("지우기") { _, _ -> Stats.reset(this); render() }
                .setNegativeButton("취소", null)
                .show()
        })
    }

    // ---------- 🔧 설정 ----------

    private fun otpEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(ComponentName(this, OtpListener::class.java).flattenToString())
    }

    private fun renderSettings() {
        listBox.removeAllViews()

        listBox.addView(text("😓 기본으로 바꿀 이모지", 16f, true))
        val def = Words.defaultEmoji(this)
        listBox.addView(button("지금: $def   ✏️ 바꾸기") {
            nameDialog("욕을 무엇으로 바꿀까요?", def) { e -> Words.setDefaultEmoji(this, e); render() }
        })
        listBox.addView(text("그룹마다 다르게 하려면 '욕 단어' 탭에서 그룹을 펼쳐서 바꾸세요.", 13f))

        listBox.addView(text("🔢 문자 인증번호 바로 붙여넣기", 16f, true))
        listBox.addView(text(
            if (otpEnabled()) "✅ 켜져 있어요. 인증번호 문자가 오면 키보드 맨 위에 3분 동안 떠요."
            else "꺼져 있어요. 아래 버튼을 누르고 '😓 키보드'를 허용해 주세요. (이 앱은 인터넷 권한이 없어서 읽은 내용이 밖으로 나가지 않아요)", 13f))
        listBox.addView(button("알림 접근 설정 열기") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        listBox.addView(text("🖼 최근 스크린샷 보여주기", 16f, true))
        val hasPhoto = ImageClips.hasPhotoPermission(this)
        listBox.addView(text(
            if (hasPhoto) "✅ 켜져 있어요. 키보드 📋 → 🖼 사진에서 최근 스크린샷이 보여요."
            else "꺼져 있어요. 켜면 키보드 📋 → 🖼 사진에서 최근 스크린샷을 바로 붙여넣을 수 있어요.", 13f))
        if (!hasPhoto) listBox.addView(button("사진 접근 허용하기") {
            val perm = if (Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_IMAGES
            else android.Manifest.permission.READ_EXTERNAL_STORAGE
            requestPermissions(arrayOf(perm), 1)
        })

        listBox.addView(text("📱 앱별로 욕 바꾸기 켜기/끄기", 16f, true))
        val seen = AppPrefs.seen(this)
        if (seen.isEmpty()) listBox.addView(text("😓 키보드로 글을 써 본 앱이 여기에 나와요.", 13f))
        else listBox.addView(text("체크를 풀면 그 앱에서는 욕이 그대로 나가요.", 13f))
        for (pkg in seen) {
            val label = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
            listBox.addView(CheckBox(this).apply {
                text = label
                textSize = 15f
                isChecked = !AppPrefs.isDisabled(this@MainActivity, pkg)
                setOnCheckedChangeListener { _, on -> AppPrefs.setDisabled(this@MainActivity, pkg, !on) }
            })
        }

        listBox.addView(text("🗣 말투 변환표", 16f, true))
        listBox.addView(text("키보드 맨 위 🗣를 누르면 쓴 글 전체를 바꿀 수 있어요.", 13f))
        val samples = listOf("존나 배고파", "오늘 뭐 했어?", "내일 같이 가자", "고마워", "감사합니다", "어디세요?")
        for (sm in samples) {
            listBox.addView(text("「$sm」", 15f, true).apply { setPadding(0, dp(8), 0, 0) })
            listBox.addView(text("😇 ${Tone.polite(sm)}\n🎙 ${Tone.idol(sm)}\n${Tone.honorificLabel(sm)}: ${Tone.honorific(sm)}", 14f)
                .apply { setPadding(dp(12), dp(2), 0, dp(2)) })
        }
        listBox.addView(text("😇 고운말로 바뀌는 말", 15f, true))
        listBox.addView(text(Tone.POLITE_MAP.joinToString("\n") { "${it.first} → ${it.second}" }, 14f)
            .apply { setPadding(dp(12), dp(2), 0, dp(2)) })
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        render()
    }

    private fun nameDialog(title: String, current: String, allowEmpty: Boolean = false, onOk: (String) -> Unit) {
        val input = noFilterEdit("이름").apply {
            isSingleLine = true
            setText(current)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("확인") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isNotEmpty() || allowEmpty) onOk(n)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun addRow(group: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, 0, dp(4))
        }
        val input = noFilterEdit("여기에 단어 추가").apply { isSingleLine = true }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply {
            text = "추가"
            setOnClickListener {
                // 띄어쓰기나 쉼표로 여러 개 한꺼번에 넣기
                val added = input.text.toString().split(' ', ',', '\n')
                    .map { it.trim() }.filter { it.isNotEmpty() }
                    .count { addWord(group, it, redraw = false) }
                input.setText("")
                if (added > 0) render()
            }
        })
        return row
    }

    /** 이미 어딘가 있으면 알려주고 안 넣음 */
    private fun addWord(group: String, raw: String, redraw: Boolean = true): Boolean {
        val w = raw.trim().trimStart('#')
        if (w.isEmpty()) return false
        val where = groups.entries.firstOrNull { (_, l) -> l.any { it.equals(w, ignoreCase = true) } }?.key
        if (where != null) {
            Toast.makeText(this, "'$w'은(는) 이미 '$where'에 있어요", Toast.LENGTH_SHORT).show()
            return false
        }
        groups.getOrPut(group) { mutableListOf() }.add(w)
        expanded.add(group)
        save()
        if (redraw) render()
        return true
    }

    private fun newGroupDialog() {
        val input = noFilterEdit("그룹 이름").apply { isSingleLine = true }
        AlertDialog.Builder(this)
            .setTitle("새 그룹")
            .setView(input)
            .setPositiveButton("만들기") { _, _ ->
                val name = input.text.toString().trim().trimStart('#')
                if (name.isNotEmpty() && name !in groups) {
                    groups[name] = mutableListOf()
                    expanded.add(name)
                    save()
                    render()
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun save() = Words.saveGroups(this, groups)

    // ---------- 작은 부품들 ----------

    private fun header(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.BLACK)
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(0xFFECEEF3.toInt())
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun wordRow(w: String, onDelete: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), 0, 0, 0)
        }
        row.addView(TextView(this).apply {
            text = w
            textSize = 16f
            setTextColor(Color.BLACK)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(0xFFD9534F.toInt())
            setPadding(dp(18), dp(8), dp(14), dp(8))
            setOnClickListener { onDelete() }
        })
        return row
    }

    private fun text(t: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(10), 0, dp(4))
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { onClick() }
    }

    private fun smallButton(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        textSize = 12f
        setTextColor(0xFFD9534F.toInt())
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.END }
    }

    /** 이 칸에서는 욕을 적어도 😓로 안 바뀜 */
    private fun noFilterEdit(hintText: String) = EditText(this).apply {
        hint = hintText
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        privateImeOptions = SwearKeyboardService.NO_FILTER
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
