package com.mine.swearkeyboard

import android.content.Context
import org.json.JSONObject

typealias Groups = LinkedHashMap<String, MutableList<String>>

object Words {
    private const val PREF = "swear_prefs"
    private const val KEY = "groups_v2"
    const val MY_GROUP = "내가 추가한 단어"

    val DEFAULT_GROUPS: List<Pair<String, List<String>>> = listOf(
        "씨발" to listOf(
            "시발", "시벌", "시빨", "시팔", "시펄", "시봘", "시뱔", "시부랄", "시부럴", "씨발", "씨벌", "씨빨", "씨뻘", "씨팔", "씨펄", "씨봘", "씨뱔", "씨부랄", "씨부럴", "쉬발", "쉬벌", "쉬빨", "쉬뻘", "쉬팔", "쉬펄", "쉬봘", "쉬뱔", "쉬부랄", "쉬부럴", "쒸발", "쒸벌", "쒸빨", "쒸뻘", "쒸팔", "쒸펄", "쒸봘", "쒸뱔", "쒸부랄", "쒸부럴", "씌발", "씌벌", "씌빨", "씌뻘", "씌팔", "씌펄", "씌봘", "씌뱔", "씌부랄", "씌부럴", "싀발", "싀벌", "싀빨", "싀뻘", "싀팔", "싀펄", "싀봘", "싀뱔", "싀부랄", "싀부럴", "쓰발", "쓰벌", "쓰빨", "쓰뻘", "쓰팔", "쓰펄", "쓰봘", "쓰뱔", "쓰부랄", "쓰부럴", "십발", "십벌", "십빨", "십뻘", "십펄", "십봘", "십뱔", "십부랄", "십부럴", "씹발", "씹벌", "씹빨", "씹뻘", "씹팔", "씹펄", "씹봘", "씹뱔", "씹부랄", "씹부럴", "쓉발", "쓉벌", "쓉빨", "쓉뻘", "쓉팔", "쓉펄", "쓉봘", "쓉뱔", "쓉부랄", "쓉부럴", "씨바", "쒸바", "씌바", "쓰바", "씨빠", "시빠", "쒸빠", "씨이발", "시이발", "씨이바", "씨이이발", "시이이발", "씨벌탱", "씨벌놈", "시벌탱", "시8", "씨8", "ㅅ8", "ㅆ8", "ㅅㅂ", "ㅆㅂ", "ㅅㅃ", "ㅆㅃ", "ㅅㅍ", "ㅆㅍ", "ㅅㅂㄹ", "ㅆㅂㄹ", "tlqkf", "sibal", "ssibal"
        ),
        "병신" to listOf(
            "병신", "븅신", "빙신", "븽신", "벙신", "뱅신", "병쉰", "븅쉰", "빙쉰", "병싄", "븅싄", "병시나", "븅시나", "빙시나", "병딱", "븅딱", "ㅂㅅ", "ㅄ", "등신", "등쉰", "덩신", "qudtls"
        ),
        "새끼" to listOf(
            "개새끼", "개색기", "개새기", "개섀끼", "개세끼", "개쉐끼", "개새키", "개색히", "개새퀴", "개쌔끼", "개쌔기", "개쌕기", "개새꺄", "개섀기", "개쉐키", "개쉨", "개쉑", "개세키", "깨새끼", "깨색기", "깨새기", "깨섀끼", "깨세끼", "깨쉐끼", "깨새키", "깨색히", "깨새퀴", "깨쌔끼", "깨쌔기", "깨쌕기", "깨새꺄", "깨섀기", "깨쉐키", "깨쉨", "깨쉑", "깨세키", "게새끼", "게색기", "게새기", "게섀끼", "게세끼", "게쉐끼", "게새키", "게색히", "게새퀴", "게쌔끼", "게쌔기", "게쌕기", "게새꺄", "게섀기", "게쉐키", "게쉨", "게쉑", "게세키", "께새끼", "께색기", "께새기", "께섀끼", "께세끼", "께쉐끼", "께새키", "께색히", "께새퀴", "께쌔끼", "께쌔기", "께쌕기", "께새꺄", "께섀기", "께쉐키", "께쉨", "께쉑", "께세키", "걔새끼", "걔색기", "걔새기", "걔섀끼", "걔세끼", "걔쉐끼", "걔새키", "걔색히", "걔새퀴", "걔쌔끼", "걔쌔기", "걔쌕기", "걔새꺄", "걔섀기", "걔쉐키", "걔쉨", "걔쉑", "걔세키", "ㄱ새끼", "ㄱ색기", "ㄱ새기", "ㄱ섀끼", "ㄱ세끼", "ㄱ쉐끼", "ㄱ새키", "ㄱ색히", "ㄱ새퀴", "ㄱ쌔끼", "ㄱ쌔기", "ㄱ쌕기", "ㄱ새꺄", "ㄱ섀기", "ㄱ쉐키", "ㄱ쉨", "ㄱ쉑", "ㄱ세키", "씹새끼", "씹색기", "씹새기", "씹섀끼", "씹세끼", "씹쉐끼", "씹새키", "씹색히", "씹새퀴", "씹쌔끼", "씹쌔기", "씹쌕기", "씹새꺄", "씹섀기", "씹쉐키", "씹쉨", "씹쉑", "씹세키", "좆새끼", "좆색기", "좆새기", "좆섀끼", "좆세끼", "좆쉐끼", "좆새키", "좆색히", "좆새퀴", "좆쌔끼", "좆쌔기", "좆쌕기", "좆새꺄", "좆섀기", "좆쉐키", "좆쉨", "좆쉑", "좆세키", "좃새끼", "좃색기", "좃새기", "좃섀끼", "좃세끼", "좃쉐끼", "좃새키", "좃색히", "좃새퀴", "좃쌔끼", "좃쌔기", "좃쌕기", "좃새꺄", "좃섀기", "좃쉐키", "좃쉨", "좃쉑", "좃세키", "호로새끼", "호로색기", "호로새기", "호로섀끼", "호로세끼", "호로쉐끼", "호로새키", "호로색히", "호로새퀴", "호로쌔끼", "호로쌔기", "호로쌕기", "호로새꺄", "호로섀기", "호로쉐키", "호로쉨", "호로쉑", "호로세키", "후레새끼", "후레색기", "후레새기", "후레섀끼", "후레세끼", "후레쉐끼", "후레새키", "후레색히", "후레새퀴", "후레쌔끼", "후레쌔기", "후레쌕기", "후레새꺄", "후레섀기", "후레쉐키", "후레쉨", "후레쉑", "후레세키", "니새끼", "니색기", "니새기", "니섀끼", "니세끼", "니쉐끼", "니새키", "니색히", "니새퀴", "니쌔끼", "니쌔기", "니쌕기", "니새꺄", "니섀기", "니쉐키", "니쉨", "니쉑", "니세키", "새끼", "색기", "섀끼", "쌔끼", "새퀴", "새꺄", "쉐끼", "색히", "ㅅㄲ", "ㄱㅅㄲ", "개섹", "개색", "개자식", "개놈", "개같은", "개같네", "개같다", "개같이", "개노답", "개빡치"
        ),
        "존나" to listOf(
            "존나", "졸라", "존내", "존니", "졸랭", "조낸", "ㅈㄴ", "쥰나", "죤나", "줜나", "쥰내", "죤내", "존니스트", "졸래", "존나게", "존낸", "jonna"
        ),
        "좆" to listOf(
            "좆", "좃", "졷", "죶", "좆같", "좃같", "졷같", "존같", "좆까", "좃까", "졷까", "ㅈ같", "ㅈ까", "좆밥", "좃밥", "ㅈ밥", "좆나", "좃나", "좆도", "좆만", "좆망", "좃망", "ㅈ망"
        ),
        "지랄·염병" to listOf(
            "지랄", "지럴", "지롤", "즤랄", "쥐랄", "질알", "ㅈㄹ", "지랄병", "염병", "염뱅", "엠병", "얌병", "옘병"
        ),
        "미친" to listOf(
            "미친놈", "미친년", "미친새끼", "미친넘", "미친뇬", "미친것", "미췬", "미틴", "믜친", "ㅁㅊ", "또라이", "돌아이", "똘아이", "또라히"
        ),
        "패드립" to listOf(
            "니미", "니애미", "니애비", "느금마", "느금", "느개비", "니엄마", "니앰", "엠창", "앰창", "애미뒤진", "애비뒤진", "애미없", "애비없", "니기미"
        ),
        "기타" to listOf(
            "엿먹어", "엿머거", "엿이나", "닥쳐", "닥처", "닥치라", "ㄷㅊ", "ㄲㅈ", "꺼지셈", "꺼지라", "썅", "썅년", "쌍년", "썅놈", "쌍놈", "잡놈", "잡년", "씹새", "씹창", "씹년", "씹놈", "씹덕", "씹할", "뒤질래", "뒤지고싶", "디질래", "디지고싶", "뒈져", "뒈질", "凸", "후장", "찐따", "한남충", "김치녀", "틀딱", "급식충", "맘충"
        ),
        "영어" to listOf(
            "fuck", "fuk", "fck", "fxck", "phuck", "fuxk", "fukk", "shit", "sh1t", "shiit", "bitch", "btch", "biatch", "b1tch", "asshole", "motherfucker", "dick", "bastard", "cunt", "wtf", "stfu", "gtfo", "nigga", "nigger"
        )
    )

    val DEFAULT: List<String> get() = DEFAULT_GROUPS.flatMap { it.second }

    fun defaultGroups(): Groups = Groups().apply {
        for ((name, list) in DEFAULT_GROUPS) put(name, list.toMutableList())
    }

    fun loadGroups(ctx: Context): Groups {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return defaultGroups()
        val g = Groups()
        var cur = MY_GROUP
        for (line in raw.split("\n")) {
            val t = line.trim()
            if (t.isEmpty()) continue
            if (t.startsWith("#")) {
                cur = t.substring(1)
                g.getOrPut(cur) { mutableListOf() }
            } else {
                g.getOrPut(cur) { mutableListOf() }.add(t)
            }
        }
        return g
    }

    fun saveGroups(ctx: Context, g: Groups) {
        val sb = StringBuilder()
        for ((name, list) in g) {
            sb.append('#').append(name).append('\n')
            for (w in list) sb.append(w).append('\n')
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, sb.toString()).apply()
    }

    /** 키보드가 쓰는 전체 단어 */
    fun load(ctx: Context): List<String> = loadGroups(ctx).values.flatten()

    // ---------- 바꿀 이모지 ----------

    private const val KEY_DEF = "default_emoji"
    private const val KEY_GROUP_EMO = "group_emoji"

    fun defaultEmoji(ctx: Context): String =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_DEF, null)?.takeIf { it.isNotBlank() } ?: "😓"

    fun setDefaultEmoji(ctx: Context, e: String) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_DEF, e.trim()).apply()
    }

    fun groupEmojis(ctx: Context): MutableMap<String, String> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_GROUP_EMO, null) ?: return mutableMapOf()
        return try {
            val o = JSONObject(raw)
            val m = mutableMapOf<String, String>()
            for (k in o.keys()) m[k] = o.optString(k)
            m
        } catch (e: Exception) {
            mutableMapOf()
        }
    }

    /** e 가 null 이거나 비어 있으면 기본 이모지 사용 */
    fun setGroupEmoji(ctx: Context, group: String, e: String?) {
        val m = groupEmojis(ctx)
        if (e.isNullOrBlank()) m.remove(group) else m[group] = e.trim()
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString(KEY_GROUP_EMO, JSONObject(m as Map<*, *>).toString()).apply()
    }

    /** 단어 -> 바꿀 이모지 */
    fun loadMap(ctx: Context): Map<String, String> {
        val def = defaultEmoji(ctx)
        val ge = groupEmojis(ctx)
        val m = LinkedHashMap<String, String>()
        for ((g, list) in loadGroups(ctx)) for (w in list) if (!m.containsKey(w)) m[w] = ge[g] ?: def
        return m
    }
}
