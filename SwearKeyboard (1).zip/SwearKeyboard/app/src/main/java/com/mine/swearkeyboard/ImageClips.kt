package com.mine.swearkeyboard

import android.Manifest
import android.content.ContentProvider
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Size
import java.io.File

/** 키보드가 다른 앱에 사진을 넘겨줄 때 쓰는 통로 (이 앱 폴더의 사진만) */
class ImageProvider : ContentProvider() {
    override fun onCreate() = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val ctx = context ?: return null
        val name = uri.lastPathSegment ?: return null
        if (name.contains('/') || name.contains("..")) return null
        val f = File(ImageClips.dir(ctx), name)
        if (!f.exists()) return null
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun getType(uri: Uri): String =
        if (uri.lastPathSegment?.endsWith(".png") == true) "image/png" else "image/jpeg"

    override fun query(uri: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<out String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<out String>?) = 0
}

object ImageClips {
    const val AUTH = "com.mine.swearkeyboard.images"
    private const val MAX = 30

    fun dir(ctx: Context): File = File(ctx.filesDir, "clipimg").apply { mkdirs() }

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun uriFor(f: File): Uri = Uri.parse("content://$AUTH/${f.name}")

    fun mimeOf(f: File) = if (f.name.endsWith(".png")) "image/png" else "image/jpeg"

    /** 다른 앱의 사진을 이 앱 폴더로 복사 */
    fun saveFromUri(ctx: Context, uri: Uri): File? {
        if (uri.authority == AUTH) return File(dir(ctx), uri.lastPathSegment ?: return null).takeIf { it.exists() }
        return try {
            val mime = ctx.contentResolver.getType(uri) ?: return null
            if (!mime.startsWith("image/")) return null
            val ext = if (mime.contains("png")) "png" else "jpg"
            val f = File(dir(ctx), "img_${Math.abs(uri.toString().hashCode())}.$ext")
            if (!f.exists()) {
                ctx.contentResolver.openInputStream(uri)?.use { input ->
                    f.outputStream().use { input.copyTo(it) }
                } ?: return null
            }
            f.setLastModified(System.currentTimeMillis())
            list(ctx).drop(MAX).forEach { it.delete() }
            f
        } catch (e: Exception) {
            null
        }
    }

    fun delete(f: File) = f.delete()

    fun hasPhotoPermission(ctx: Context): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
    }

    /** 최근 스크린샷 (사진 권한이 있을 때만) */
    fun recentScreenshots(ctx: Context, limit: Int): List<Uri> {
        if (!hasPhotoPermission(ctx)) return emptyList()
        val out = ArrayList<Uri>()
        try {
            val col = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val (sel, args) = if (Build.VERSION.SDK_INT >= 29)
                "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?" to arrayOf("%Screenshots%")
            else
                "${MediaStore.Images.Media.DATA} LIKE ?" to arrayOf("%Screenshots%")
            ctx.contentResolver.query(
                col, arrayOf(MediaStore.Images.Media._ID), sel, args,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < limit) out.add(ContentUris.withAppendedId(col, c.getLong(0)))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun thumb(ctx: Context, f: File, px: Int): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= px && o.outHeight / (s * 2) >= px) s *= 2
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (e: Exception) {
        null
    }

    fun thumb(ctx: Context, uri: Uri, px: Int): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(uri, Size(px, px), null)
        else MediaStore.Images.Thumbnails.getThumbnail(
            ctx.contentResolver, ContentUris.parseId(uri), MediaStore.Images.Thumbnails.MINI_KIND, null
        )
    } catch (e: Exception) {
        null
    }
}
