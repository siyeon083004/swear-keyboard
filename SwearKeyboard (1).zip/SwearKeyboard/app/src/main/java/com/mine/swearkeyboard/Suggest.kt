package com.mine.swearkeyboard

/**
 * 추천줄: 커서 앞 글을 보고 추천을 만든다.
 * 누르면 커서 앞 replaceLen 글자를 지우고 insert 를 넣는다.
 */
object Suggest {
    data class Sug(val label: String, val replaceLen: Int, val insert: String)

    fun compute(before: String): List<Sug> {
        val out = ArrayList<Sug>()
        calc(before)?.let { out.add(it) }
        engKor(before)?.let { out.add(it) }
        spelling(before)?.let { out.add(it) }
        spacing(before)?.let { out.add(it) }
        out.addAll(emoji(before))
        return out
    }

    // ---------- 계산기 ----------

    private val CALC = Regex("""(?<![\d.])(\d[\d,]*(?:\.\d+)?(?:\s*[-+*/×÷xX]\s*\d[\d,]*(?:\.\d+)?)+)\s*(=?)\s*$""")

    fun calc(before: String): Sug? {
        val m = CALC.find(before) ?: return null
        val expr = m.groupValues[1]
        val v = evaluate(expr) ?: return null
        val res = format(v)
        return if (m.groupValues[2] == "=") Sug("= $res", 0, res) else Sug("= $res", 0, "=$res")
    }

    private fun format(v: Double): String {
        if (v == Math.floor(v) && Math.abs(v) < 1e15) return v.toLong().toString()
        return String.format(java.util.Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
    }

    /** 덧셈·뺄셈·곱셈·나눗셈 (곱셈·나눗셈 먼저) */
    fun evaluate(expr: String): Double? {
        val tokens = Regex("""\d[\d,]*(?:\.\d+)?|[-+*/×÷xX]""").findAll(expr).map { it.value }.toList()
        if (tokens.isEmpty()) return null
        val nums = ArrayList<Double>()
        val ops = ArrayList<Char>()
        for ((i, t) in tokens.withIndex()) {
            if (i % 2 == 0) nums.add(t.replace(",", "").toDoubleOrNull() ?: return null)
            else ops.add(when (t) { "×", "x", "X" -> '*'; "÷" -> '/'; else -> t[0] })
        }
        if (nums.size != ops.size + 1) return null
        // 곱셈·나눗셈
        val n2 = arrayListOf(nums[0])
        val o2 = ArrayList<Char>()
        for (i in ops.indices) {
            val o = ops[i]
            val b = nums[i + 1]
            when (o) {
                '*' -> n2[n2.size - 1] = n2.last() * b
                '/' -> { if (b == 0.0) return null; n2[n2.size - 1] = n2.last() / b }
                else -> { o2.add(o); n2.add(b) }
            }
        }
        var r = n2[0]
        for (i in o2.indices) r = if (o2[i] == '+') r + n2[i + 1] else r - n2[i + 1]
        return r
    }

    // ---------- 한영 고침 ----------

    private val ENG_WORD = Regex("""(?<![A-Za-z])([A-Za-z]{2,})$""")

    fun engKor(before: String): Sug? {
        val w = ENG_WORD.find(before)?.groupValues?.get(1) ?: return null
        val k = Hangul.engToKor(w)
        // 한글로 바꿨을 때 남는 자음·모음 없이 완전한 글자일 때만 (hello 같은 진짜 영어는 제외)
        if (k.isEmpty() || !k.all { Hangul.isSyllable(it) }) return null
        return Sug(k, w.length, k)
    }

    // ---------- 맞춤법 ----------

    val SPELL = listOf(
        "됬" to "됐", "몇일" to "며칠", "몇 일" to "며칠", "않되" to "안 되", "않돼" to "안 돼",
        "안되요" to "안 돼요", "되요" to "돼요", "뵈요" to "봬요", "할께" to "할게", "될께" to "될게",
        "갈께" to "갈게", "줄께" to "줄게", "볼께" to "볼게", "할꺼" to "할 거", "갈꺼" to "갈 거",
        "금새" to "금세", "왠만" to "웬만", "웬지" to "왠지", "일일히" to "일일이", "설겆이" to "설거지",
        "희안" to "희한", "오랫만" to "오랜만", "역활" to "역할", "바램" to "바람", "어의없" to "어이없",
        "궂이" to "굳이", "곰곰히" to "곰곰이", "깨끗히" to "깨끗이", "설레임" to "설렘", "않해" to "안 해",
        "않하" to "안 하", "않가" to "안 가", "않먹" to "안 먹", "내꺼" to "내 거", "니꺼" to "네 거",
        "어떻해" to "어떡해", "대려" to "데려", "몇칠" to "며칠", "건들이" to "건드리", "왠일" to "웬일",
        "구지" to "굳이", "어짜피" to "어차피", "어쨋든" to "어쨌든", "문안하" to "무난하", "애기" to "아기"
    )

    fun spelling(before: String): Sug? {
        val m = Regex("""(\S+(?: 일)?)$""").find(before) ?: return null
        val tok = m.groupValues[1]
        for ((wrong, right) in SPELL) {
            if (tok.contains(wrong)) {
                val fixed = tok.replace(wrong, right)
                if (fixed != tok) return Sug(fixed, tok.length, fixed)
            }
        }
        return null
    }

    // ---------- 이모지 추천 ----------

    val EMOJI_MAP = listOf(
        "ㅠㅠ" to "😭", "ㅜㅜ" to "😭", "ㅋㅋ" to "😂", "ㅎㅎ" to "😊", "사랑" to "❤️", "하트" to "💕",
        "축하" to "🎉", "생일" to "🎂", "배고" to "🍚", "졸려" to "😴", "졸리" to "😴", "잘자" to "🌙",
        "화나" to "😡", "짜증" to "😤", "고마" to "🙏", "감사" to "🙏", "미안" to "🙇", "죄송" to "🙇",
        "대박" to "😲", "좋아" to "👍", "굿" to "👍", "ㅇㅋ" to "👌", "오케이" to "👌", "헐" to "😮",
        "슬퍼" to "😢", "피곤" to "😩", "더워" to "🥵", "추워" to "🥶", "커피" to "☕", "피자" to "🍕",
        "치킨" to "🍗", "게임" to "🎮", "공부" to "📚", "학교" to "🏫", "돈" to "💰", "불타" to "🔥",
        "최고" to "🏆", "귀여" to "🥰", "무서" to "😱", "웃겨" to "🤣", "아파" to "🤒", "음악" to "🎵",
        "노래" to "🎤", "비와" to "☔", "눈와" to "⛄", "파이팅" to "💪", "화이팅" to "💪", "안녕" to "👋"
    )

    fun emoji(before: String): List<Sug> {
        val tok = Regex("""(\S+)$""").find(before)?.groupValues?.get(1) ?: return emptyList()
        val out = ArrayList<Sug>()
        for ((k, e) in EMOJI_MAP) {
            if (tok.endsWith(k) || (k.length >= 2 && tok.contains(k))) {
                if (out.none { it.insert == e }) out.add(Sug(e, 0, e))
                if (out.size >= 2) break
            }
        }
        return out
    }

    // ---------- 자동 띄어쓰기 ----------

    fun spacing(before: String): Sug? {
        val m = Regex("""([가-힣]{4,})$""").find(before) ?: return null
        val chunk = m.groupValues[1]
        val seg = Spacing.segment(chunk) ?: return null
        if (!seg.contains(' ') || seg == chunk) return null
        return Sug(seg, chunk.length, seg)
    }
}

/** 자주 쓰는 말 사전으로 붙여 쓴 문장 나누기 */
object Spacing {
    private val WORDS = (
        // 명사·대명사·부사
        "오늘 내일 어제 모레 지금 나중 아까 이따 이따가 밥 집 학교 학원 회사 친구 엄마 아빠 형 누나 언니 오빠 동생 " +
        "선생님 쌤 우리 저희 나 너 저 걔 쟤 얘 뭐 왜 어디 언제 누구 어떻게 진짜 너무 완전 같이 그냥 빨리 천천히 " +
        "많이 조금 좀 또 이제 아직 벌써 다시 정말 게임 영화 공부 숙제 시험 운동 노래 사진 전화 문자 카톡 연락 " +
        "시간 사람 생각 돈 물 커피 치킨 피자 라면 떡볶이 점심 저녁 아침 주말 방학 생일 선물 중 거 것 때 날 번 " +
        "이거 저거 그거 여기 거기 저기 노래방 피시방 편의점 버스 지하철 택시 차 밖 안 위 아래 앞 뒤 옆 " +
        "제일 가장 별로 엄청 되게 약간 혹시 아마 꼭 절대 계속 먼저 바로 다음 처음 마지막 오랜만 요즘 " +
        "휴대폰 핸드폰 폰 컴퓨터 유튜브 인스타 영상 사진 문제 이유 기분 마음 얘기 이야기 말 일 " +
        "그래서 그런데 근데 그리고 그럼 그러니까 하지만 그래도 " +
        // 동사·형용사 줄기 (+ 자주 쓰는 바뀐 모양)
        "먹 가 갔 오 왔 와 보 봤 봐 하 했 해 자 잤 놀 만나 만났 좋 싫 알 몰 모르 있 없 되 됐 돼 주 줬 줘 받 " +
        "사 샀 마시 마셨 일어나 일어났 씻 기다리 기다려 기다렸 찾 듣 들었 들어 읽 쓰 썼 써 타 탔 내리 웃 울 살 " +
        "배우 배웠 끝나 끝났 보내 보냈 만들 열 닫 앉 걷 뛰 입 싶 같 괜찮 재밌 재미있 재미없 맛있 맛없 피곤하 피곤해 " +
        "졸리 졸려 배고프 배고파 배불러 아프 아파 예쁘 예뻐 귀엽 귀여워 춥 추워 덥 더워 고마워 미안 미안해 사랑해 " +
        "좋아하 좋아해 싫어하 싫어해 할 갈 올 볼 잘 못 안 나가 나갔 들어가 들어갔 들어와 돌아가 돌아와 " +
        "시작하 시작했 시작해 공부하 공부해 공부했 운동하 운동해 연락하 연락해 전화하 전화해 생각하 생각해 생각했"
        ).split(" ").filter { it.isNotEmpty() }.toSet()

    private val SUFFIX = (
        " 은 는 이 가 을 를 에 에서 에게 한테 께 랑 이랑 하고 도 만 의 로 으로 까지 부터 처럼 보다 이나 나 " +
        "요 야 아 이야 이에요 예요 이다 다 에도 에서도 에는 에서는 한테도 인데 이랑도 " +
        "어 여 어요 아요 여요 었어 았어 였어 었어요 았어요 었다 았다 자 러 으러 고 서 어서 아서 는 은 을 " +
        "는데 은데 지 지만 네 니 냐 게 을게 거야 을거야 겠다 겠어 면 으면 니까 으니까 려고 으려고 을래 래 " +
        "기 음 어라 아라 세요 으세요 셨어 었는데 았는데 는거 은거 을거 던 " +
        "죠 잖아 거든 구나 네요 군요 대 래요 대요 냐고 자고 라고 다고 거 건 걸"
        ).split(" ").toSet()

    private fun ok(seg: String): Boolean {
        for (end in seg.length downTo 1) {
            val w = seg.substring(0, end)
            if (w in WORDS && seg.substring(end) in SUFFIX) return true
        }
        return false
    }

    /** 모든 부분이 사전으로 설명되면 띄어 쓴 문장, 아니면 null */
    fun segment(s: String): String? {
        val n = s.length
        val best = IntArray(n + 1) { Int.MAX_VALUE }
        val from = IntArray(n + 1) { -1 }
        best[0] = 0
        for (i in 0 until n) {
            if (best[i] == Int.MAX_VALUE) continue
            for (j in i + 1..minOf(n, i + 8)) {
                if (best[i] + 1 < best[j] && ok(s.substring(i, j))) {
                    best[j] = best[i] + 1
                    from[j] = i
                }
            }
        }
        if (best[n] == Int.MAX_VALUE || best[n] < 2) return null
        val parts = ArrayList<String>()
        var k = n
        while (k > 0) { parts.add(s.substring(from[k], k)); k = from[k] }
        return parts.reversed().joinToString(" ")
    }
}
