package com.mine.swearkeyboard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** 욕 카운터 */
object Stats {
    private const val PREF = "stats"
    private const val KEY = "data"

    private fun day(d: Date) = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(d)
    fun today(): String = day(Date())

    private fun load(ctx: Context): JSONObject {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, null) ?: return JSONObject()
        return try { JSONObject(raw) } catch (e: Exception) { JSONObject() }
    }

    private fun save(ctx: Context, o: JSONObject) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, o.toString()).apply()
    }

    fun record(ctx: Context, word: String) {
        val o = load(ctx)
        o.put("total", o.optInt("total") + 1)
        val days = o.optJSONObject("days") ?: JSONObject()
        val t = today()
        days.put(t, days.optInt(t) + 1)
        o.put("days", days)
        val words = o.optJSONObject("words") ?: JSONObject()
        words.put(word, words.optInt(word) + 1)
        o.put("words", words)
        save(ctx, o)
    }

    class Snapshot(val total: Int, val today: Int, val week: Int, val top: List<Pair<String, Int>>, val last7: List<Pair<String, Int>>)

    fun snapshot(ctx: Context): Snapshot {
        val o = load(ctx)
        val days = o.optJSONObject("days") ?: JSONObject()
        val cal = Calendar.getInstance()
        val last7 = ArrayList<Pair<String, Int>>()
        for (i in 0 until 7) {
            val d = day(cal.time)
            last7.add(d to days.optInt(d))
            cal.add(Calendar.DAY_OF_MONTH, -1)
        }
        val words = o.optJSONObject("words") ?: JSONObject()
        val top = ArrayList<Pair<String, Int>>()
        for (k in words.keys()) top.add(k to words.optInt(k))
        top.sortByDescending { it.second }
        return Snapshot(o.optInt("total"), days.optInt(today()), last7.sumOf { it.second }, top.take(10), last7.reversed())
    }

    fun reset(ctx: Context) = save(ctx, JSONObject())
}

/** 앱별 켜기/끄기 */
object AppPrefs {
    private const val PREF = "app_prefs"

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    /** 키보드를 써 본 앱들 (최근 순) */
    fun seen(ctx: Context): List<String> {
        val raw = p(ctx).getString("seen", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addSeen(ctx: Context, pkg: String) {
        val list = seen(ctx).toMutableList()
        if (list.firstOrNull() == pkg) return
        list.remove(pkg)
        list.add(0, pkg)
        while (list.size > 60) list.removeAt(list.size - 1)
        p(ctx).edit().putString("seen", JSONArray(list).toString()).apply()
    }

    fun disabled(ctx: Context): Set<String> = p(ctx).getStringSet("off", emptySet()) ?: emptySet()

    fun isDisabled(ctx: Context, pkg: String) = pkg in disabled(ctx)

    fun setDisabled(ctx: Context, pkg: String, off: Boolean) {
        val s = HashSet(disabled(ctx))
        if (off) s.add(pkg) else s.remove(pkg)
        p(ctx).edit().putStringSet("off", s).apply()
    }

    // 기타 설정
    fun getBool(ctx: Context, key: String, def: Boolean) = p(ctx).getBoolean(key, def)
    fun setBool(ctx: Context, key: String, v: Boolean) = p(ctx).edit().putBoolean(key, v).apply()
}

/** 문자로 온 인증번호 (3분 동안만) */
object OtpStore {
    private const val PREF = "otp"
    const val LIFE_MS = 3 * 60 * 1000L

    fun put(ctx: Context, code: String) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("code", code).putLong("time", System.currentTimeMillis()).apply()
    }

    fun get(ctx: Context): String? {
        val p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val code = p.getString("code", null) ?: return null
        if (System.currentTimeMillis() - p.getLong("time", 0) > LIFE_MS) return null
        return code
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("code").apply()
    }

    private val KEYWORDS = listOf("인증", "확인", "본인", "보안", "otp", "code", "코드", "verification", "번호")

    /** 알림 글에서 인증번호 찾기 */
    fun extract(text: String): String? {
        val low = text.lowercase()
        if (KEYWORDS.none { low.contains(it) }) return null
        // "인증번호 [123456]" 처럼 키워드 바로 뒤에 오는 숫자 먼저
        Regex("""(?:인증|확인|보안|코드|code|otp)[^\d]{0,12}(\d{4,8})(?!\d)""", RegexOption.IGNORE_CASE)
            .find(text)?.let { return it.groupValues[1] }
        // 전화번호(010-..., 1588-...)는 빼고 4~8자리 숫자
        for (m in Regex("""(?<![\d-])(\d{4,8})(?![\d-])""").findAll(text)) return m.groupValues[1]
        return null
    }
}
