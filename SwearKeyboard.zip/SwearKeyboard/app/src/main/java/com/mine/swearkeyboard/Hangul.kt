package com.mine.swearkeyboard

/** 두벌식 한글 조합 */
object Hangul {
    const val CHO = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
    const val JUNG = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ"
    const val JONG = " ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ"

    val VOWEL_COMB = mapOf(
        "ㅗㅏ" to 'ㅘ', "ㅗㅐ" to 'ㅙ', "ㅗㅣ" to 'ㅚ',
        "ㅜㅓ" to 'ㅝ', "ㅜㅔ" to 'ㅞ', "ㅜㅣ" to 'ㅟ', "ㅡㅣ" to 'ㅢ'
    )
    val JONG_COMB = mapOf(
        "ㄱㅅ" to 'ㄳ', "ㄴㅈ" to 'ㄵ', "ㄴㅎ" to 'ㄶ', "ㄹㄱ" to 'ㄺ', "ㄹㅁ" to 'ㄻ',
        "ㄹㅂ" to 'ㄼ', "ㄹㅅ" to 'ㄽ', "ㄹㅌ" to 'ㄾ', "ㄹㅍ" to 'ㄿ', "ㄹㅎ" to 'ㅀ', "ㅂㅅ" to 'ㅄ'
    )
    val VOWEL_SPLIT: Map<Char, String> = VOWEL_COMB.entries.associate { it.value to it.key }
    val JONG_SPLIT: Map<Char, String> = JONG_COMB.entries.associate { it.value to it.key }

    fun isVowel(c: Char) = JUNG.indexOf(c) >= 0
    fun isJamoKey(c: Char) = CHO.indexOf(c) >= 0 || JUNG.indexOf(c) >= 0
    fun canBeJong(c: Char) = JONG.indexOf(c) > 0

    /** 글자를 자판 입력 순서(자모)로 풀기: "개새끼" -> "ㄱㅐㅅㅐㄲㅣ" */
    fun toJamo(s: String): String {
        val sb = StringBuilder()
        for (ch in s) {
            if (ch in '가'..'힣') {
                val code = ch - '가'
                val ci = code / (21 * 28)
                val ji = (code % (21 * 28)) / 28
                val ti = code % 28
                sb.append(CHO[ci])
                val v = JUNG[ji]
                sb.append(VOWEL_SPLIT[v] ?: v.toString())
                if (ti > 0) {
                    val t = JONG[ti]
                    sb.append(JONG_SPLIT[t] ?: t.toString())
                }
            } else {
                sb.append(VOWEL_SPLIT[ch] ?: JONG_SPLIT[ch] ?: ch.toString())
            }
        }
        return sb.toString()
    }
}

/** 지금 조합 중인 한 글자 */
data class Syl(val cho: Char? = null, val jung: Char? = null, val jong: Char? = null) {
    val isEmpty get() = cho == null && jung == null && jong == null

    fun text(): String {
        if (cho != null && jung != null) {
            val ci = Hangul.CHO.indexOf(cho)
            val ji = Hangul.JUNG.indexOf(jung)
            val ti = if (jong == null) 0 else Hangul.JONG.indexOf(jong)
            return (0xAC00 + (ci * 21 + ji) * 28 + ti).toChar().toString()
        }
        return listOfNotNull(cho, jung, jong).joinToString("")
    }
}

object Composer {
    /** 자모 하나 입력 -> (확정할 글자, 새로 조합 중인 글자) */
    fun input(s: Syl, k: Char): Pair<String, Syl> {
        if (Hangul.isVowel(k)) {
            return when {
                s.isEmpty -> "" to Syl(jung = k)
                s.jong != null -> {
                    val split = Hangul.JONG_SPLIT[s.jong]
                    if (split != null) Syl(s.cho, s.jung, split[0]).text() to Syl(split[1], k)
                    else Syl(s.cho, s.jung).text() to Syl(s.jong, k)
                }
                s.jung == null -> "" to Syl(s.cho, k)
                else -> {
                    val comb = Hangul.VOWEL_COMB["${s.jung}$k"]
                    if (comb != null) "" to s.copy(jung = comb) else s.text() to Syl(jung = k)
                }
            }
        } else {
            return when {
                s.isEmpty -> "" to Syl(cho = k)
                s.cho != null && s.jung != null && s.jong == null ->
                    if (Hangul.canBeJong(k)) "" to s.copy(jong = k) else s.text() to Syl(cho = k)
                s.jong != null -> {
                    val comb = Hangul.JONG_COMB["${s.jong}$k"]
                    if (comb != null) "" to s.copy(jong = comb) else s.text() to Syl(cho = k)
                }
                else -> s.text() to Syl(cho = k)
            }
        }
    }

    fun backspace(s: Syl): Syl = when {
        s.jong != null -> {
            val sp = Hangul.JONG_SPLIT[s.jong]
            if (sp != null) s.copy(jong = sp[0]) else s.copy(jong = null)
        }
        s.jung != null -> {
            val sp = Hangul.VOWEL_SPLIT[s.jung]
            if (sp != null) s.copy(jung = sp[0]) else s.copy(jung = null)
        }
        else -> Syl()
    }
}

class SwearFilter(words: List<String>) {
    private val list = words.map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        .distinct().sortedByDescending { it.length }
    private val jamoList = list.map { Hangul.toJamo(it) }
    private val jamoSet = jamoList.toSet()

    /** 글 끝이 욕으로 끝나면 그 길이를 돌려줌 */
    fun matchEnd(text: String): Int? {
        val low = text.lowercase()
        for (w in list) if (low.endsWith(w)) return w.length

        // 사이에 숫자·기호를 끼워 넣은 것도 잡기: 시1발, 시.발, 병~신, f*ck
        if (low.isEmpty() || SEP.indexOf(low.last()) >= 0) return null
        val idx = ArrayList<Int>()
        val sb = StringBuilder()
        for ((i, c) in low.withIndex()) if (SEP.indexOf(c) < 0) { sb.append(c); idx.add(i) }
        val norm = sb.toString()
        for (w in list) {
            if (w.length < 2 || !norm.endsWith(w)) continue
            val len = low.length - idx[norm.length - w.length]
            if (len <= w.length * 3) return len
        }
        return null
    }

    companion object {
        const val SEP = "0123456789.,~!@#\$%^&*()_+-=/\\|'\"`:;?<>[]{}♡♥☆★·ㆍ…"
    }

    /**
     * 😓로 바꾼 뒤 이어서 친 자모까지 합친 j가
     * 2 = 욕 완성, 1 = 더 치면 욕이 될 수 있음, 0 = 상관없음
     * (끝부분만 봐도 됨: "개새" 다음 "끼" -> "새끼")
     */
    fun continues(j: String): Int {
        for (i in 0..j.length - 2) if (j.substring(i) in jamoSet) return 2
        for (i in 0..j.length - 2) {
            val s = j.substring(i)
            if (jamoList.any { it.startsWith(s) }) return 1
        }
        return 0
    }
}
