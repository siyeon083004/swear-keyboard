package com.mine.swearkeyboard

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView

class SwearKeyboardService : InputMethodService() {

    companion object {
        const val EMOJI = "😓"
        const val NO_FILTER = "com.mine.swearkeyboard.nofilter"

        const val KO1 = "ㅂㅈㄷㄱㅅㅛㅕㅑㅐㅔ"
        const val KO1_SHIFT = "ㅃㅉㄸㄲㅆㅛㅕㅑㅒㅖ"
        const val KO2 = "ㅁㄴㅇㄹㅎㅗㅓㅏㅣ"
        const val KO3 = "ㅋㅌㅊㅍㅠㅜㅡ"
        const val EN1 = "qwertyuiop"
        const val EN2 = "asdfghjkl"
        const val EN3 = "zxcvbnm"
        const val SYM1 = "!@#$%^&*()"
        const val SYM2 = "-_=+/\\:;'\""
        const val SYM3 = "~?|<>[]{}"
    }

    enum class Mode { KO, EN, SYM }

    private class Key(
        val label: String,
        val weight: Float = 1f,
        val special: Boolean = false,
        val spacer: Boolean = false,
        val repeat: Boolean = false,
        val highlight: Boolean = false,
        val onLong: (() -> Unit)? = null,
        val action: () -> Unit = {}
    )

    private var mode = Mode.KO
    private var lastLang = Mode.KO
    private var shift = false
    private var syl = Syl()
    private var filter = SwearFilter(Words.DEFAULT)
    private var filterOn = true

    // 욕을 😓로 바꾼 직후, 이어서 치는 글자가 더 긴 욕이면(시바 -> 시발) 계속 삼키기
    private var repActive = false
    private var repJamo = ""
    private val repExtra = StringBuilder()

    private var root: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())

    // ---------- 생명주기 ----------

    override fun onCreateInputView(): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1E1F24.toInt())
            setPadding(dp(3), dp(4), dp(3), dp(8))
        }
        root = r
        build()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        filter = SwearFilter(Words.load(this))
        filterOn = info?.let { shouldFilter(it) } ?: true
        syl = Syl()
        clearRep()
        shift = false
        if (mode == Mode.SYM) mode = lastLang
        build()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        finishComposing()
        clearRep()
        super.onFinishInputView(finishingInput)
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // 사용자가 커서를 다른 곳으로 옮기면 조합 끝내기
        if (!syl.isEmpty && candidatesEnd != -1 &&
            (newSelStart != candidatesEnd || newSelEnd != candidatesEnd)
        ) {
            currentInputConnection?.finishComposingText()
            syl = Syl()
            clearRep()
        }
    }

    private fun shouldFilter(info: EditorInfo): Boolean {
        if (info.privateImeOptions?.contains(NO_FILTER) == true) return false
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val v = info.inputType and InputType.TYPE_MASK_VARIATION
        if (cls == InputType.TYPE_CLASS_TEXT && (v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD)
        ) return false
        return true
    }

    // ---------- 입력 처리 ----------

    private fun onCharKey(s: String) {
        if (mode == Mode.KO && s.length == 1 && Hangul.isJamoKey(s[0])) onJamo(s[0]) else onText(s)
        if (shift) {
            shift = false
            build()
        }
    }

    private fun onJamo(k: Char) {
        val ic = currentInputConnection ?: return
        if (repActive) {
            val cand = repJamo + repExtra + k
            when (filter.continues(cand)) {
                2 -> { repJamo = cand; repExtra.clear(); return }
                1 -> { repExtra.append(k); return }
            }
            val pending = repExtra.toString()
            clearRep()
            for (p in pending) composeJamo(ic, p)
        }
        composeJamo(ic, k)
        checkSwear()
    }

    private fun composeJamo(ic: InputConnection, k: Char) {
        val (commit, next) = Composer.input(syl, k)
        if (commit.isNotEmpty()) ic.commitText(commit, 1)
        syl = next
        ic.setComposingText(syl.text(), 1)
    }

    private fun onText(s: String) {
        val ic = currentInputConnection ?: return
        flushRep(ic)
        finishComposing()
        ic.commitText(s, 1)
        checkSwear()
    }

    private fun checkSwear() {
        if (!filterOn) return
        val ic = currentInputConnection ?: return
        val comp = if (syl.isEmpty) "" else syl.text()
        var before = ic.getTextBeforeCursor(64, 0)?.toString() ?: ""
        if (comp.isNotEmpty() && !before.endsWith(comp)) before += comp
        val len = filter.matchEnd(before) ?: return
        val matched = before.takeLast(len)

        ic.beginBatchEdit()
        ic.finishComposingText()
        ic.deleteSurroundingText(len, 0)
        ic.commitText(EMOJI, 1)
        ic.endBatchEdit()

        syl = Syl()
        repActive = mode == Mode.KO
        repJamo = Hangul.toJamo(matched.lowercase().filter { SwearFilter.SEP.indexOf(it) < 0 })
        repExtra.clear()
    }

    private fun clearRep() {
        repActive = false
        repJamo = ""
        repExtra.clear()
    }

    /** 삼켜두었던 글자가 욕이 아니었으면 다시 입력 */
    private fun flushRep(ic: InputConnection) {
        if (!repActive) return
        val pending = repExtra.toString()
        clearRep()
        for (p in pending) composeJamo(ic, p)
    }

    private fun finishComposing() {
        if (!syl.isEmpty) {
            currentInputConnection?.finishComposingText()
            syl = Syl()
        }
    }

    private fun onBackspace() {
        val ic = currentInputConnection ?: return
        if (repActive && repExtra.isNotEmpty()) {
            repExtra.deleteCharAt(repExtra.length - 1)
            return
        }
        clearRep()
        if (!syl.isEmpty) {
            syl = Composer.backspace(syl)
            if (syl.isEmpty) ic.commitText("", 1) else ic.setComposingText(syl.text(), 1)
            return
        }
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
            return
        }
        val b = ic.getTextBeforeCursor(2, 0)
        if (b.isNullOrEmpty()) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            return
        }
        val n = if (b.length == 2 && Character.isSurrogatePair(b[0], b[1])) 2 else 1
        ic.deleteSurroundingText(n, 0)
    }

    private fun onEnter() {
        val ic = currentInputConnection ?: return
        flushRep(ic)
        finishComposing()
        clearRep()
        val ei = currentInputEditorInfo
        val opts = ei?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnter = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noEnter && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun endInputState() {
        currentInputConnection?.let { flushRep(it) }
        finishComposing()
        clearRep()
    }

    private fun toggleLang() {
        endInputState()
        mode = when (mode) {
            Mode.KO -> Mode.EN
            Mode.EN -> Mode.KO
            Mode.SYM -> if (lastLang == Mode.KO) Mode.EN else Mode.KO
        }
        lastLang = mode
        shift = false
        build()
    }

    private fun toggleSym() {
        endInputState()
        mode = if (mode == Mode.SYM) lastLang else Mode.SYM
        shift = false
        build()
    }

    private fun showPicker() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    // ---------- 자판 화면 ----------

    private fun letters(s: String): List<Key> = s.map { c -> Key(c.toString()) { onCharKey(c.toString()) } }
    private fun spacer(w: Float) = Key("", w, spacer = true)
    private fun shiftKey() = Key("⇧", 1.5f, special = true, highlight = shift) { shift = !shift; build() }
    private fun backKey() = Key("⌫", 1.5f, special = true, repeat = true) { onBackspace() }

    private fun build() {
        val r = root ?: return
        r.removeAllViews()
        row(letters("1234567890"))
        when (mode) {
            Mode.KO -> {
                row(letters(if (shift) KO1_SHIFT else KO1))
                row(listOf(spacer(0.5f)) + letters(KO2) + spacer(0.5f))
                row(listOf(shiftKey()) + letters(KO3) + backKey())
            }
            Mode.EN -> {
                fun f(s: String) = if (shift) s.uppercase() else s
                row(letters(f(EN1)))
                row(listOf(spacer(0.5f)) + letters(f(EN2)) + spacer(0.5f))
                row(listOf(shiftKey()) + letters(f(EN3)) + backKey())
            }
            Mode.SYM -> {
                row(letters(SYM1))
                row(letters(SYM2))
                row(letters(SYM3) + backKey())
            }
        }
        val symLabel = if (mode == Mode.SYM) (if (lastLang == Mode.KO) "가" else "ABC") else "!#1"
        val langLabel = if (mode == Mode.EN || (mode == Mode.SYM && lastLang == Mode.EN)) "영/한" else "한/영"
        row(
            listOf(
                Key(symLabel, 1.4f, special = true) { toggleSym() },
                Key(langLabel, 1.3f, special = true, onLong = { showPicker() }) { toggleLang() },
                Key(",") { onText(",") },
                Key("$EMOJI 키보드", 4f) { onText(" ") },
                Key(".") { onText(".") },
                Key("⏎", 1.6f, special = true) { onEnter() }
            )
        )
    }

    private fun row(keys: List<Key>) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (k in keys) {
            val lp = LinearLayout.LayoutParams(0, dp(50), k.weight)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            r.addView(makeKey(k), lp)
        }
        root?.addView(r, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
    }

    private fun makeKey(k: Key): View {
        if (k.spacer) return View(this)
        val color = when {
            k.highlight -> 0xFF4C8DF6.toInt()
            k.special -> 0xFF3A3C44.toInt()
            else -> 0xFF5B5E69.toInt()
        }
        val bg = GradientDrawable().apply {
            cornerRadius = dp(7).toFloat()
            setColor(color)
        }
        val tv = TextView(this).apply {
            text = k.label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = if (k.label.length > 2) 14f else 20f
            if (k.special) typeface = Typeface.DEFAULT_BOLD
            background = RippleDrawable(ColorStateList.valueOf(0x55FFFFFF), bg, null)
            isClickable = true
        }
        if (k.repeat) {
            val rep = object : Runnable {
                override fun run() {
                    k.action()
                    handler.postDelayed(this, 50)
                }
            }
            tv.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        v.isPressed = true
                        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        k.action()
                        handler.postDelayed(rep, 400)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.isPressed = false
                        handler.removeCallbacks(rep)
                    }
                }
                true
            }
        } else {
            tv.setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                k.action()
            }
            k.onLong?.let { long -> tv.setOnLongClickListener { long(); true } }
        }
        return tv
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
