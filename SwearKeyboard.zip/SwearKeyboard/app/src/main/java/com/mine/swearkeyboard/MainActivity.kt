package com.mine.swearkeyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var groups: Groups
    private val expanded = HashSet<String>()
    private lateinit var listBox: LinearLayout
    private lateinit var search: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        groups = Words.loadGroups(this)

        val pad = dp(18)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        col.addView(text("😓 키보드", 28f, true))
        col.addView(text("욕을 치는 순간 바로 😓로 바뀌는 나만의 키보드예요. 전송을 아무리 빨리 눌러도 이미 바뀐 상태로 나가요."))

        col.addView(text("처음 한 번만 하면 돼요", 18f, true))
        col.addView(button("1단계: 설정에서 '😓 키보드' 켜기") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        })
        col.addView(button("2단계: 이 키보드로 바꾸기") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })

        col.addView(text("😓로 바꿀 단어", 18f, true))
        col.addView(text("그룹을 누르면 그 안의 변형들이 펼쳐져요. ✕를 누르면 그 단어는 안 바뀌어요.", 13f))

        search = noFilterEdit("🔍 검색 (예: 씨발, 새끼, ㅅㅂ)").apply {
            isSingleLine = true
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) = render()
            })
        }
        col.addView(search)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)

        col.addView(button("+ 새 그룹 만들기") { newGroupDialog() })
        col.addView(button("기본 목록으로 되돌리기") {
            AlertDialog.Builder(this)
                .setMessage("내가 추가하거나 지운 단어가 다 처음 상태로 돌아가요. 되돌릴까요?")
                .setPositiveButton("되돌리기") { _, _ ->
                    groups = Words.defaultGroups()
                    save()
                    render()
                }
                .setNegativeButton("취소", null)
                .show()
        })

        col.addView(text("여기서 테스트해 보세요", 18f, true))
        col.addView(EditText(this).apply { hint = "욕을 쳐보세요" })

        setContentView(ScrollView(this).apply { addView(col) })
        render()
    }

    // ---------- 목록 그리기 ----------

    private fun render() {
        listBox.removeAllViews()
        val q = search.text.toString().trim().lowercase()
        var shownAny = false

        for ((name, list) in groups) {
            val nameHit = q.isNotEmpty() && name.lowercase().contains(q)
            val matches = if (q.isEmpty() || nameHit) list else list.filter { it.lowercase().contains(q) }
            if (q.isNotEmpty() && matches.isEmpty() && !nameHit) continue
            shownAny = true

            val open = q.isNotEmpty() || name in expanded
            val title = buildString {
                append(if (open) "▼  " else "▶  ")
                append(name)
                append("   ${list.size}개")
                if (q.isNotEmpty() && !nameHit) append("  ·  ${matches.size}개 찾음")
            }
            listBox.addView(header(title) {
                if (q.isEmpty()) {
                    if (!expanded.remove(name)) expanded.add(name)
                    render()
                }
            })

            if (open) {
                for (w in matches) listBox.addView(wordRow(w) {
                    list.remove(w)
                    save()
                    render()
                })
                listBox.addView(addRow(name))
                listBox.addView(smallButton("이 그룹 삭제") {
                    AlertDialog.Builder(this)
                        .setMessage("'$name' 그룹을 통째로 지울까요? (${list.size}개)")
                        .setPositiveButton("삭제") { _, _ ->
                            groups.remove(name)
                            expanded.remove(name)
                            save()
                            render()
                        }
                        .setNegativeButton("취소", null)
                        .show()
                })
            }
        }

        if (!shownAny && q.isNotEmpty()) {
            listBox.addView(text("'$q'은(는) 목록에 없어요.", 15f))
            listBox.addView(button("'$q' 추가하기") {
                addWord(Words.MY_GROUP, q)
                search.setText("")
            })
        }
    }

    private fun addRow(group: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, 0, dp(4))
        }
        val input = noFilterEdit("여기에 단어 추가").apply { isSingleLine = true }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Button(this).apply {
            text = "추가"
            setOnClickListener {
                // 띄어쓰기나 쉼표로 여러 개 한꺼번에 넣기
                val added = input.text.toString().split(' ', ',', '\n')
                    .map { it.trim() }.filter { it.isNotEmpty() }
                    .count { addWord(group, it, redraw = false) }
                input.setText("")
                if (added > 0) render()
            }
        })
        return row
    }

    /** 이미 어딘가 있으면 알려주고 안 넣음 */
    private fun addWord(group: String, raw: String, redraw: Boolean = true): Boolean {
        val w = raw.trim().trimStart('#')
        if (w.isEmpty()) return false
        val where = groups.entries.firstOrNull { (_, l) -> l.any { it.equals(w, ignoreCase = true) } }?.key
        if (where != null) {
            Toast.makeText(this, "'$w'은(는) 이미 '$where'에 있어요", Toast.LENGTH_SHORT).show()
            return false
        }
        groups.getOrPut(group) { mutableListOf() }.add(w)
        expanded.add(group)
        save()
        if (redraw) render()
        return true
    }

    private fun newGroupDialog() {
        val input = noFilterEdit("그룹 이름").apply { isSingleLine = true }
        AlertDialog.Builder(this)
            .setTitle("새 그룹")
            .setView(input)
            .setPositiveButton("만들기") { _, _ ->
                val name = input.text.toString().trim().trimStart('#')
                if (name.isNotEmpty() && name !in groups) {
                    groups[name] = mutableListOf()
                    expanded.add(name)
                    save()
                    render()
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun save() = Words.saveGroups(this, groups)

    // ---------- 작은 부품들 ----------

    private fun header(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.BLACK)
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(0xFFECEEF3.toInt())
        }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun wordRow(w: String, onDelete: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), 0, 0, 0)
        }
        row.addView(TextView(this).apply {
            text = w
            textSize = 16f
            setTextColor(Color.BLACK)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(TextView(this).apply {
            text = "✕"
            textSize = 18f
            setTextColor(0xFFD9534F.toInt())
            setPadding(dp(18), dp(8), dp(14), dp(8))
            setOnClickListener { onDelete() }
        })
        return row
    }

    private fun text(t: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(10), 0, dp(4))
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { onClick() }
    }

    private fun smallButton(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        textSize = 12f
        setTextColor(0xFFD9534F.toInt())
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { gravity = Gravity.END }
    }

    /** 이 칸에서는 욕을 적어도 😓로 안 바뀜 */
    private fun noFilterEdit(hintText: String) = EditText(this).apply {
        hint = hintText
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        privateImeOptions = SwearKeyboardService.NO_FILTER
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
