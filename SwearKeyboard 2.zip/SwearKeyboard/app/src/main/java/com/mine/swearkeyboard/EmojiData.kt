package com.mine.swearkeyboard

import android.content.Context
import org.json.JSONArray

/** 전체 이모지 (assets/emoji.tsv: 분류 \t 이모지 \t 한국어 검색어) */
object EmojiData {
    class E(val group: Int, val ch: String, val words: String)

    /** 분류 탭 아이콘: 표정·사람 / 동물 / 음식 / 여행·장소 / 활동 / 사물 / 기호 / 깃발 */
    val GROUP_ICONS = listOf("😀", "🐶", "🍔", "🏠", "⚽", "💡", "🔣", "🏳️")

    private var cache: List<E>? = null

    fun all(ctx: Context): List<E> {
        cache?.let { return it }
        val list = try {
            ctx.assets.open("emoji.tsv").bufferedReader().readLines().mapNotNull { line ->
                val p = line.split('\t')
                if (p.size < 3) null else E(p[0].toIntOrNull() ?: 0, p[1], p[2].lowercase())
            }
        } catch (e: Exception) {
            emptyList()
        }
        cache = list
        return list
    }

    fun group(ctx: Context, g: Int): List<String> = all(ctx).filter { it.group == g }.map { it.ch }

    fun search(ctx: Context, q: String): List<String> {
        val k = q.trim().lowercase()
        if (k.isEmpty()) return emptyList()
        return all(ctx).filter { it.words.contains(k) }.map { it.ch }.take(100)
    }

    // ---------- 최근 쓴 이모지 ----------

    private const val PREF = "emoji_prefs"
    private const val MAX_RECENT = 40

    fun recent(ctx: Context): List<String> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("recent", null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun addRecent(ctx: Context, e: String) {
        val list = recent(ctx).toMutableList()
        list.remove(e)
        list.add(0, e)
        while (list.size > MAX_RECENT) list.removeAt(list.size - 1)
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("recent", JSONArray(list).toString()).apply()
    }
}
